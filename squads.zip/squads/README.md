# Squads

An open-source mobile, desktop, and web chat app

## Getting Started

1. Ensure you have the Azure Developer CLI installed. If not, [follow the instructions here](https://learn.microsoft.com/azure/developer/azure-developer-cli/install-azd).
1. Ensure you have PowerShell 7 installed. If not, [follow the instructions here](https://learn.microsoft.com/powershell/scripting/install/installing-powershell).
1. Sign in to your Azure account by running `azd auth login`.
1. Initialize the App Host project - navigate into the `src/Orchestration/Squads.AppHost` directory and run `azd init`.
1. Deploy the solution by running `azd up`.

## Generating the Client Project

The client project is already generated, and has some additional features that are not automatically generated. However, if you need to regenerate the client project, follow these steps:

1. Copy the URL for the `api-service` endpoint.
1. Generate the client project by running `Generate-ClientProject` in the PowerShell terminal from the root of the repository, passing the URL from step 6 as the first argument.
