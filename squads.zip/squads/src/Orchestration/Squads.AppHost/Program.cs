using Squads.Constants;

var builder = DistributedApplication.CreateBuilder(args);

var storage = builder.AddAzureStorage(ServiceConstants.STORAGE_SERCVICE)
    .RunAsEmulator()
    //.ConfigureInfrastructure((infra) =>
    //    {
    //        var storageAccount = infra.GetProvisionableResources()
    //            .OfType<StorageAccount>()
    //            .FirstOrDefault(r => r.BicepIdentifier == ServiceConstants.STORAGE_SERCVICE)
    //            ?? throw new Exception("Storage account not found");

    //        storageAccount.Sku = new StorageSku
    //        {
    //            Name = new BicepValue<StorageSkuName>(StorageSkuName.StandardLrs)
    //        };
    //    }
    //)
    .AddBlobs(ServiceConstants.PROFILE_BLOB);

//var dbServer = builder.AddPostgres(ServiceConstants.DATABASE_SERVER)
//    .WithDataVolume(isReadOnly: false)
//    .WithPgAdmin();

var dbServer = builder.AddAzurePostgresFlexibleServer(ServiceConstants.DATABASE_SERVER);

var squadsDb = dbServer.AddDatabase(ServiceConstants.SQUADS_DATABASE);

var apiService = builder.AddProject<Projects.Squads_ApiService>(ServiceConstants.API_SERVICE)
    .WithExternalHttpEndpoints()
    .WithReference(storage)
    .WithReference(squadsDb);

builder.AddProject<Projects.Squads_Web>(ServiceConstants.WEB_UI)
    .WithExternalHttpEndpoints()
    .WithReference(apiService)
    .WaitFor(apiService);

builder.Build().Run();
