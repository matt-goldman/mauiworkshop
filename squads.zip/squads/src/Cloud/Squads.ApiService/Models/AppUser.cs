﻿using Microsoft.AspNetCore.Identity;

namespace Squads.ApiService.Models;

public class AppUser : IdentityUser
{
    public ICollection<UserChat> UserChats { get; set; } = new List<UserChat>();

    public ICollection<Chat> Chats => UserChats.Select(uc => uc.Chat).ToList();

    public string Firstname { get; set; } = string.Empty;

    public string Lastname { get; set; } = string.Empty;

    public string Fullname => $"{Firstname} {Lastname}";

    public string ProfilePictureUrl { get; set; } = string.Empty;
}
