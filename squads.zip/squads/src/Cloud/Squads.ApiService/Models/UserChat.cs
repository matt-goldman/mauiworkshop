﻿namespace Squads.ApiService.Models;

public class UserChat
{
    public int Id { get; set; }

    public string UserId { get; set; } = null!;
    public AppUser User { get; set; } = null!;

    public int ChatId { get; set; }
    public Chat Chat { get; set; } = null!;

    public string AddedById { get; set; } = string.Empty;
    public AppUser AddedBy { get; set; } = null!;

    public DateTime AddedAt { get; set; } = DateTime.UtcNow;

    public DateTime? LeftAt { get; set; } = null;

    public bool IsCurrent => !LeftAt.HasValue;

}
