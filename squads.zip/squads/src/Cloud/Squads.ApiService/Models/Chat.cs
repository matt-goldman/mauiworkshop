﻿namespace Squads.ApiService.Models;

public class Chat
{
    public int Id { get; set; }

    public Guid ReferralId { get; set; } = Guid.NewGuid();

    public string Name { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public ICollection<Message> Messages { get; set; } = new List<Message>();

    public ICollection<UserChat> UserChats { get; set; } = new List<UserChat>();

    //public Message? LastMessage { get; set; } = null;
    //public int? LastMessageId { get; set; } = null;
}
