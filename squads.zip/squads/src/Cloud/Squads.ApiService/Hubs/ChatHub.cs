﻿using Squads.ApiService.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;
using Squads.Shared;
using Squads.Shared.Messages;

namespace Squads.ApiService.Hubs;

[Authorize]
public class ChatHub(IChatService chatService, IUserService userService, IUserConnectionManager userConnectionManager) : Hub
{
    public override Task OnConnectedAsync()
    {
        var userId = Context.UserIdentifier;

        userConnectionManager.AddConnection(userId, Context.ConnectionId);

        return base.OnConnectedAsync();
    }

    public override Task OnDisconnectedAsync(Exception? exception)
    {
        userConnectionManager.RemoveConnection(Context.ConnectionId);

        return base.OnDisconnectedAsync(exception);
    }

    public async Task SendMessage(ChatMessage message)
    {
        await chatService.ProcessAndSaveMessage(message);

        if (message.ChatId == 1)
        {
            await Clients.All.SendAsync(MessageConstants.RECEIVE, message);
        }
        else
        {
            await userConnectionManager.EnsureInDictionary(chatService, chatId: message.ChatId);
            var referralId = userConnectionManager.GetReferralId(message.ChatId);
            await Clients.Group(referralId).SendAsync(MessageConstants.RECEIVE, message);
        }
    }

    public async Task CreateChat(string name, List<string> users)
    {
        var chat = await chatService.CreateChat(name, users, CancellationToken.None);

        await userConnectionManager.EnsureInDictionary(chatService, chat.referralId, chat.id);

        foreach (var user in users)
        {
            var connections = userConnectionManager.GetConnectionIds(user);
            foreach (var connection in connections)
            {
                await Groups.AddToGroupAsync(connection, chat.referralId);
            }
        }

        var message = new ChatMessage
        {
            ChatId = chat.id,
            Message = $"Chat {name} has been created",
            SenderName = "System",
            SentUtc = DateTime.UtcNow,
        };

        await Clients.Group(chat.referralId).SendAsync(MessageConstants.RECEIVE, message);
    }

    public async Task AddUserToChat(string userId, string referralId)
    {
        await chatService.AddUserToChat(userId, referralId, CancellationToken.None);

        var connections = userConnectionManager.GetConnectionIds(userId);

        foreach (var connection in connections)
        {
            await Groups.AddToGroupAsync(connection, referralId);
        }

        await userConnectionManager.EnsureInDictionary(chatService, referralId: referralId);

        var user = await userService.GetUser(userId, CancellationToken.None);

        var message = new ChatMessage
        {
            Message = $"{user.FullName} has been added to the chat",
            SenderName = "System",
            SentUtc = DateTime.UtcNow,
        };

        await Clients.Group(referralId).SendAsync(MessageConstants.RECEIVE, message);
    }

    public async Task JoinChat(string referralId)
    {
        var user = await userService.GetMyProfile(CancellationToken.None);

        // TODO: save this in the chat history
        var message = new ChatMessage
        {
            Message = $"{user.FullName} has joined the chat",
            SenderName = "System",
            SentUtc = DateTime.UtcNow,
        };

        await Clients.Group(referralId).SendAsync(MessageConstants.RECEIVE, message);

        await chatService.JoinChat(referralId, CancellationToken.None);

        await userConnectionManager.EnsureInDictionary(chatService, referralId);

        await Groups.AddToGroupAsync(Context.ConnectionId, referralId);
    }

    public async Task LeaveChat(string referralId)
    {
        var user = await userService.GetMyProfile(CancellationToken.None);

        await userConnectionManager.EnsureInDictionary(chatService, referralId);

        // TODO: save this in the chat history
        var message = new ChatMessage
        {
            Message = $"{user.FullName} has left the chat",
            SenderName = "System",
            SentUtc = DateTime.UtcNow,
        };

        await Clients.Group(referralId).SendAsync(MessageConstants.RECEIVE, message);

        await chatService.LeaveChat(referralId, CancellationToken.None);

        await Groups.RemoveFromGroupAsync(Context.ConnectionId, referralId);
    }
    
    public async Task StartTyping(int chatId)
    {
        var user = await userService.GetMyProfile(CancellationToken.None);
        
        var notification = new StartedTypingNotification
        {
            UserId = user.Id,
            ChatId = chatId
        };

        var referralId = userConnectionManager.GetReferralId(chatId);

        await Clients.Group(referralId).SendAsync(MessageConstants.START_TYPING, notification);
    }
    
    public async Task StopTyping(int chatId)
    {
        var user = await userService.GetMyProfile(CancellationToken.None);
        
        var notification = new StoppedTypingNotification
        {
            UserId = user.Id,
            ChatId = chatId
        };

        var referralId = userConnectionManager.GetReferralId(chatId);

        await Clients.Group(referralId).SendAsync(MessageConstants.STOP_TYPING, notification);
    }
}