﻿using Squads.ApiService.Models;
using Squads.Shared.DTOs;

namespace Squads.ApiService.Projections;

public static class UserProjections
{
    public static UserProfileDto ToDto(this AppUser user, bool isMe)
    {
        return new UserProfileDto
        {
            Id = user.Id,
            FirstName = user.Firstname,
            LastName = user.Lastname,
            ProfilePictureUrl = user.ProfilePictureUrl,
            Email = user.UserName,
            IsMe = isMe
        };
    }
}
