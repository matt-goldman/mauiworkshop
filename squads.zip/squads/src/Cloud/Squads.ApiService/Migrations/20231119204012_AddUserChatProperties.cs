﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Squads.ApiService.Migrations
{
    /// <inheritdoc />
    public partial class AddUserChatProperties : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<DateTime>(
                name: "AddedAt",
                table: "UserChat",
                type: "timestamp with time zone",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "AddedById",
                table: "UserChat",
                type: "text",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<DateTime>(
                name: "LeftAt",
                table: "UserChat",
                type: "timestamp with time zone",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_UserChat_AddedById",
                table: "UserChat",
                column: "AddedById");

            migrationBuilder.AddForeignKey(
                name: "FK_UserChat_AspNetUsers_AddedById",
                table: "UserChat",
                column: "AddedById",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_UserChat_AspNetUsers_AddedById",
                table: "UserChat");

            migrationBuilder.DropIndex(
                name: "IX_UserChat_AddedById",
                table: "UserChat");

            migrationBuilder.DropColumn(
                name: "AddedAt",
                table: "UserChat");

            migrationBuilder.DropColumn(
                name: "AddedById",
                table: "UserChat");

            migrationBuilder.DropColumn(
                name: "LeftAt",
                table: "UserChat");
        }
    }
}
