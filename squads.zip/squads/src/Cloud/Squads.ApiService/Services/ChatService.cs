﻿using Squads.ApiService.Exceptions;
using Squads.ApiService.Models;
using Squads.ApiService.Persistence;
using Microsoft.EntityFrameworkCore;
using Squads.Shared.Messages;
using System.Security.Claims;

namespace Squads.ApiService.Services;

public interface IChatService
{
    Task ProcessAndSaveMessage(ChatMessage message);
    Task <(string referralId, int id)> CreateChat(string name, List<string> users, CancellationToken cancellationToken);
    Task AddUserToChat(string userId, string referralId, CancellationToken cancellationToken);
    Task RemoveUserFromChat(string userId, string referralId, CancellationToken cancellationToken);
    Task JoinChat(string referralId, CancellationToken cancellationToken);
    Task LeaveChat(string referralId, CancellationToken cancellationToken);
    Task <List<Message>> GetChatMessages(string referralId, CancellationToken cancellationToken);
    Task <List<AppUser>> GetChatUsers(string referralId, CancellationToken cancellationToken);
    Task <List<Chat>> GetMyChats(CancellationToken cancellationToken);
    Task<Chat> GetChat(string referralId, CancellationToken cancellationToken, bool? includeMessages = false);
    Task<Chat> GetChat(int Id, CancellationToken cancellationToken, bool? includeMessages = false);
    Task<Chat> GetChat(List<string> userIds, CancellationToken cancellationToken, bool? includeMessages = false);
}

public class ChatService(
    IUserService userService,
    TimeProvider timeProvider,
    IHttpContextAccessor httpContextAccessor,
    ApplicationDbContext dbContext) : IChatService
{
    public async Task AddUserToChat(string userId, string referralId, CancellationToken cancellationToken)
    {
        var chat = await dbContext.Chats
            .Include(c => c.UserChats)
            .FirstOrDefaultAsync(c => c.ReferralId.ToString() == referralId, cancellationToken);

        if (chat is null)
        {
            throw new NotFoundException($"Chat not found: {referralId}");
        }

        if (!chat.UserChats.Any(u => u.UserId == userId))
        {
            var currentUserId = httpContextAccessor.HttpContext?.User?.FindFirstValue(ClaimTypes.NameIdentifier);

            chat.UserChats.Add(new UserChat
            {
                UserId      = userId,
                AddedAt     = timeProvider.GetUtcNow().UtcDateTime,
                AddedById   = currentUserId,
            });

            await dbContext.SaveChangesAsync(cancellationToken);
        }
    }

    public async Task<(string, int)> CreateChat(string name, List<string> userIds, CancellationToken cancellationToken)
    {
        var chat = new Chat
        {
            Name        = String.IsNullOrWhiteSpace(name)?Guid.NewGuid().ToString() : name,
            CreatedAt   = timeProvider.GetUtcNow().UtcDateTime,
        };

        var userId = httpContextAccessor.HttpContext?.User?.FindFirstValue(ClaimTypes.NameIdentifier);

        var now = timeProvider.GetUtcNow().UtcDateTime;

        chat.UserChats.Add(new UserChat
        {
            UserId      = userId!,
            AddedAt     = now,
            AddedById   = userId!,
        });

        foreach (var id in userIds.Where(i => i != userId))
        {
            chat.UserChats.Add(new UserChat
            {
                UserId      = id!,
                AddedAt     = now,
                AddedById   = userId!,
            });
        }

        dbContext.Chats.Add(chat);
        await dbContext.SaveChangesAsync(cancellationToken);

        return (chat.ReferralId.ToString(), chat.Id);
    }

    public async Task<List<Message>> GetChatMessages(string referralId, CancellationToken cancellationToken)
    {
        return await dbContext.Messages
            .Where(m => m.Chat.ReferralId.ToString() == referralId)
            .AsNoTracking()
            .ToListAsync(cancellationToken);
    }

    public async Task<Chat> GetChat(string referralId, CancellationToken cancellationToken, bool? includeMessages = false) // TODO: add pagination
    {
        var userId = httpContextAccessor.HttpContext?.User?.FindFirstValue(ClaimTypes.NameIdentifier);

        var query = dbContext.Chats
                .Include(c => c.UserChats)
                    .ThenInclude(uc => uc.User)
            .AsNoTracking();

        if (includeMessages == true)
        {
            query = query
                .Include(c => c.Messages)
                    .ThenInclude(m => m.Sender);
        }

        var chat = await query
            .FirstOrDefaultAsync(c => c.ReferralId.ToString() == referralId, cancellationToken);

        if (chat is null)
        {
            throw new NotFoundException($"Chat not found: {referralId}");
        }

        await HydrateChatName(chat, userId!, cancellationToken);

        return chat;
    }

    public async Task<Chat> GetChat(int id, CancellationToken cancellationToken, bool? includeMessages = false) // TODO: add pagination
    {
        var userId = httpContextAccessor.HttpContext?.User?.FindFirstValue(ClaimTypes.NameIdentifier);

        var query = dbContext.Chats
            .AsNoTracking();

        if (includeMessages == true)
        {
            query = query
                .Include(c => c.Messages)
                .ThenInclude(m => m.Sender);
        }

        var chat = await query
            .FirstOrDefaultAsync(c => c.Id == id, cancellationToken);

        if (chat is null)
        {
            throw new NotFoundException($"Chat not found: {id}");
        }

        await HydrateChatName(chat, userId!, cancellationToken);

        return chat;
    }

    public async Task<Chat> GetChat(List<string> userIds, CancellationToken cancellationToken, bool? includeMessages = false)
    {
        var userId = httpContextAccessor.HttpContext?.User?.FindFirstValue(ClaimTypes.NameIdentifier);

        var query = dbContext.Chats
            .AsNoTracking()
            .Include(c => c.UserChats)
                .ThenInclude(uc => uc.User)
            .Where(c => c.UserChats.Count == userIds.Count)
            .Where(c => c.UserChats.All(uc => userIds.Contains(uc.UserId)));

        if (includeMessages == true)
        {
            query = query
                .Include(c => c.Messages)
                .ThenInclude(m => m.Sender);
        }

        var chat = await query
            .FirstOrDefaultAsync(cancellationToken);

        if (chat is null)
        {
            throw new NotFoundException($"Chat not found: {string.Join(",", userIds)}");
        }

        await HydrateChatName(chat, userId!, cancellationToken);

        return chat;
    }

    public async Task<List<AppUser>> GetChatUsers(string referralId, CancellationToken cancellationToken)
    {
        return await dbContext.Users
            .Where(u => u.UserChats.Any(uc => uc.Chat.ReferralId.ToString() == referralId))
            .AsNoTracking()
            .ToListAsync(cancellationToken);
    }

    public async Task<List<Chat>> GetMyChats(CancellationToken cancellationToken)
    {
        var id = httpContextAccessor.HttpContext?.User?.FindFirstValue(ClaimTypes.NameIdentifier);

        var myChats = await dbContext.UserChat
            .Where(uc => uc.ChatId != 1)
            .Where(uc => uc.UserId == id && !uc.LeftAt.HasValue)
            .Include(uc => uc.Chat)
                .ThenInclude(chat => chat.UserChats)
                    .ThenInclude(userChat => userChat.User)
            .Include(uc => uc.Chat)
                .ThenInclude(chat => chat.Messages.OrderByDescending(m => m.CreatedAt).Take(1))
            .Select(uc => new
            {
                uc.Chat,
                LatestMessage = uc.Chat.Messages.OrderByDescending(m => m.CreatedAt).FirstOrDefault()
            })
            .OrderByDescending(x => x.Chat.Messages.Any() ? x!.LatestMessage!.CreatedAt : DateTime.MinValue)
            .Select(x => x.Chat)
            .AsNoTracking()
            .ToListAsync(cancellationToken);


        foreach (var chat in myChats)
        {
            await HydrateChatName(chat, id!, cancellationToken);
        }

        return myChats;
    }

    public Task JoinChat(string referralId, CancellationToken cancellationToken)
    {
        var myId = httpContextAccessor.HttpContext?.User?.FindFirstValue(ClaimTypes.NameIdentifier);

        return AddUserToChat(myId, referralId, cancellationToken);
    }

    public Task LeaveChat(string referralId, CancellationToken cancellationToken)
    {
        var mydId = httpContextAccessor.HttpContext?.User?.FindFirstValue(ClaimTypes.NameIdentifier);
        return RemoveUserFromChat(mydId, referralId, cancellationToken);
    }

    public async Task ProcessAndSaveMessage(ChatMessage message)
    {
        await EnrichMessage(message);

        if (message.ChatId > 1)
        {
            await SaveMessage(message);
        }
    }

    public async Task RemoveUserFromChat(string userId, string referralId, CancellationToken cancellationToken)
    {
        var chat = await dbContext.Chats
            .Include(c => c.UserChats)
            .FirstOrDefaultAsync(c => c.ReferralId.ToString() == referralId);

        if (chat is null)
        {
            throw new NotFoundException($"Chat not found: {referralId}");
        }

        var userChat = chat.UserChats.FirstOrDefault(uc => uc.UserId == userId);
        if (userChat is null)
        {
            return;
        }

        userChat.LeftAt = timeProvider.GetUtcNow().UtcDateTime;

        await dbContext.SaveChangesAsync(cancellationToken);
    }

    private async Task EnrichMessage(ChatMessage message)
    {
        var currentUser = await userService.GetMyProfile(CancellationToken.None);

        message.SenderId = currentUser.Id;
        message.SenderName = currentUser.FullName;
        message.SenderPicUrl = currentUser.ProfilePictureUrl;

        message.SentUtc = timeProvider.GetUtcNow().UtcDateTime;

        message.ChatId = message.ChatId == 0 ? 1 : message.ChatId;
    }

    private async Task SaveMessage(ChatMessage message)
    {
        var dbMessage = await dbContext.Messages.FindAsync(message.Id);

        if (dbMessage == null)
        {
            dbMessage = new Message
            {
                SenderId = message.SenderId,
                CreatedAt = message.SentUtc,
                LastUpdatedAt = message.SentUtc,
                Content = message.Message,
                ChatId = message.ChatId,
            };

            dbContext.Messages.Add(dbMessage);
        }
        else
        {
            dbMessage.Content = message.Message;
            dbMessage.LastUpdatedAt = message.SentUtc;
        }

        await dbContext.SaveChangesAsync();

        message.Id = dbMessage.Id;
    }

    private async Task HydrateChatName(Chat chat, string userId, CancellationToken cancellationToken)
    {
        if (Guid.TryParse(chat.Name, out var guid))
        {
            var users = await dbContext.Users
                .Where(u => u.UserChats.Any(uc => uc.ChatId == chat.Id && uc.UserId != userId))
                .ToListAsync(cancellationToken);

            chat.Name = string.Join(", ", users.Select(u => u.Fullname));
        }
    }
}
