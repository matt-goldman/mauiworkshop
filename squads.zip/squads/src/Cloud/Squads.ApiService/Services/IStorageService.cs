﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Specialized;

namespace Squads.ApiService.Services;

public interface IStorageService
{
    Task UploadPicture(string fileName, Stream data);
    Task<Uri> GetPictureUri(string fileName);
    Task GetPictureAsync(string fileName, Stream stream);
}

public class AzureStorageService : IStorageService
{
    private readonly BlobServiceClient _blobServiceClient;

    private const string PROFILE_PICTURE_CONTAINER = "profilepictures";

    public AzureStorageService(BlobServiceClient blobServiceClient)
    {
        _blobServiceClient = blobServiceClient;
    }

    public Task<Uri> GetPictureUri(string fileName)
    {
        throw new NotImplementedException();
    }

    public async Task UploadPicture(string fileName, Stream data)
    {
        var container = _blobServiceClient.GetBlobContainerClient(PROFILE_PICTURE_CONTAINER);

        await container.CreateIfNotExistsAsync();
        
        if (await container.ExistsAsync())
        {
            var blob = container.GetBlockBlobClient(fileName);

            await blob.UploadAsync(data);
        }
        else
        {
            throw new Exception("Could not create blob container");
        }
    }

    public async Task GetPictureAsync(string fileName, Stream stream)
    {
        var container = _blobServiceClient.GetBlobContainerClient(PROFILE_PICTURE_CONTAINER);

        if (await container.ExistsAsync())
        {
            var blob = container.GetBlockBlobClient(fileName);

            await blob.DownloadToAsync(stream);
        }
        else
        {
            throw new Exception("Could not create blob container");
        }
    }
}