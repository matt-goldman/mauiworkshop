﻿using Squads.ApiService.Exceptions;
using Squads.ApiService.Models;
using Squads.ApiService.Persistence;
using Squads.ApiService.Projections;
using Microsoft.EntityFrameworkCore;
using Squads.Shared.DTOs;
using System.Security.Claims;

namespace Squads.ApiService.Services;

public interface IUserService
{
    Task<UserProfileDto> GetUser(string id, CancellationToken cancellationToken);

    Task<UserProfileDto> UpsertMyProfile(UserProfileDto user, CancellationToken cancellationToken);

    Task<UserProfileDto> GetMyProfile(CancellationToken cancellationToken);

    Task<List<UserProfileDto>> SearchUser(string searchTerm, int page, int pageSize, CancellationToken cancellationToken);

    Task<List<UserProfileDto>> GetUsers(int page, int pageSize, CancellationToken cancellationToken);

    Task UploadProfilePicture(Stream data, CancellationToken cancellationToken);
}

public class UserService : IUserService
{
    private readonly ApplicationDbContext _context;
    private readonly IHttpContextAccessor _httpContext;
    private readonly ILogger<UserService> _logger;
    private readonly IStorageService _storageService;

    public UserService(ApplicationDbContext context, IHttpContextAccessor httpContext, ILogger<UserService> logger, IStorageService storageService)
    {
        _context = context;
        _httpContext = httpContext;
        _logger = logger;
        _storageService = storageService;
    }

    public async Task<UserProfileDto> GetUser(string id, CancellationToken cancellationToken)
    {
        var dbUser = await GetCurrentDbUser(cancellationToken, throwOnNotFound: true);

        var user = dbUser!.ToDto(false);

        var myId = _httpContext.HttpContext?.User?.FindFirstValue(ClaimTypes.NameIdentifier);

        if (myId != null && myId == id)
        {
            user.IsMe = true;
        }

        return user;
    }

    public async Task<UserProfileDto> UpsertMyProfile(UserProfileDto user, CancellationToken cancellationToken)
    {
        var dbUser = await GetCurrentDbUser(cancellationToken, trackChanges: true);

        if (dbUser == null)
        {
            dbUser = new AppUser();
            _context.Users.Add(dbUser);
        }

        dbUser.Firstname = user.FirstName;
        dbUser.Lastname = user.LastName;
        dbUser.ProfilePictureUrl = user.ProfilePictureUrl;
        dbUser.Email = user.Email;

        await _context.SaveChangesAsync(cancellationToken);

        user.IsMe = true;
        user.Id = dbUser.Id;

        return user;

    }

    public async Task<UserProfileDto> GetMyProfile(CancellationToken cancellationToken)
    {
        var dbUser = await GetCurrentDbUser(cancellationToken, throwOnNotFound: true);

        var user = dbUser!.ToDto(true);

        return user;
    }

    public async Task<List<UserProfileDto>> GetUsers(int page, int pageSize, CancellationToken cancellationToken)
    {
        var myId = _httpContext.HttpContext?.User?.FindFirstValue(ClaimTypes.NameIdentifier);

        var query = _context.Users
            .Where(u => u.Email != "seeded@seed.seed")
            .OrderBy(u => u.Firstname)
            .Take(pageSize)
            .Select(u => u.ToDto(u.Id == myId));

        if (page > 1)
        {
            query = query.Skip(page * pageSize);
        }

        return await query.ToListAsync(cancellationToken);
    }

    public async Task<List<UserProfileDto>> SearchUser (string searchTerm, int page, int pageSize, CancellationToken cancellationToken)
    {
        searchTerm = searchTerm.ToLower();

        var myId = _httpContext.HttpContext?.User?.FindFirstValue(ClaimTypes.NameIdentifier);

        var results = await _context.Users
            .Where(u => (u.Firstname.ToLower().Contains(searchTerm) || u.Lastname.Contains(searchTerm)) && u.Id != myId)
            .Skip(page > 1 ? --page * pageSize : 0)
            .Take(pageSize)
            .ToListAsync(cancellationToken);

        return results.Select(u => u.ToDto(false)).ToList();
    }

    public async Task UploadProfilePicture(Stream data, CancellationToken cancellationToken)
    {
        var dbUser = await GetCurrentDbUser(cancellationToken, true, true);

        var filename = Guid.NewGuid().ToString();

        await _storageService.UploadPicture(filename, data);

        var request = _httpContext.HttpContext?.Request;
        var host = $"{request?.Scheme}://{request?.Host}";

        dbUser!.ProfilePictureUrl = $"{host}/api/images/{filename}";

        await _context.SaveChangesAsync(cancellationToken);
    }

    private async Task<AppUser?> GetCurrentDbUser(CancellationToken cancellationToken, bool trackChanges = false, bool throwOnNotFound = false)
    {
        var myId = _httpContext.HttpContext?.User?.FindFirstValue(ClaimTypes.NameIdentifier);

        if (myId == null)
        {
            throw new UnauthorizedAccessException();
        }

        IQueryable<AppUser> query = _context.Users;

        if (!trackChanges)
        {
            query = query.AsNoTracking();
        }

        var dbUser = await query.FirstOrDefaultAsync(u => u.Id == myId, cancellationToken);

        if (dbUser == null && throwOnNotFound)
        {
            _logger.LogError("User {id} not found", myId);
            throw new NotFoundException($"User {myId} not found");
        }

        return dbUser;
    }
}
