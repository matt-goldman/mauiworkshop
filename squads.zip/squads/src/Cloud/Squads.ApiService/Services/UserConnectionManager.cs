﻿using System.Collections.Concurrent;

namespace Squads.ApiService.Services;

public interface IUserConnectionManager
{
    void AddConnection(string userId, string connectionId);

    void RemoveConnection(string connectionId);

    IEnumerable<string> GetConnectionIds(string userId);

    string GetReferralId(int chatId);

    Task EnsureInDictionary(IChatService? chatService, string? referralId = null, int? chatId = null);
}

public class UserConnectionManager : IUserConnectionManager
{
    private readonly ConcurrentDictionary<string, HashSet<string>> _userConnections = new();

    ConcurrentDictionary<string, int> ChatGroups = new();

    public void AddConnection(string userId, string connectionId)
    {
        _userConnections.AddOrUpdate(userId,
            new HashSet<string> { connectionId },
            (key, oldValue) => { oldValue.Add(connectionId); return oldValue; });
    }

    public void RemoveConnection(string connectionId)
    {
        foreach (var userId in _userConnections.Keys)
        {
            if (_userConnections[userId].Remove(connectionId) && _userConnections[userId].Count == 0)
            {
                _userConnections.TryRemove(userId, out _);
            }
        }
    }

    public IEnumerable<string> GetConnectionIds(string userId)
    {
        if (_userConnections.TryGetValue(userId, out var connections))
        {
            return connections;
        }

        return Enumerable.Empty<string>();
    }

    public async Task EnsureInDictionary(IChatService? chatService, string? referralId = null, int? chatId = null)
    {
        if (chatService is null && (string.IsNullOrWhiteSpace(referralId) || chatId is null))
        {
            throw new ArgumentNullException("Chat service is required if referral ID and chat ID are not both provided.");
        }

        if (!string.IsNullOrWhiteSpace(referralId) && chatId.HasValue)
        {
            ChatGroups.TryAdd(referralId, chatId.Value);

            return;
        }

        if (!string.IsNullOrWhiteSpace(referralId))
        {
            if (!ChatGroups.ContainsKey(referralId))
            {
                var chat = await chatService!.GetChat(referralId, CancellationToken.None);

                ChatGroups.TryAdd(referralId, chat.Id);

                return;
            }
        }

        if (string.IsNullOrWhiteSpace(referralId) && chatId.HasValue)
        {
            var chat = await chatService!.GetChat(chatId.Value, CancellationToken.None);

            ChatGroups.TryAdd(chat.ReferralId.ToString(), chat.Id);

            return;
        }
    }

    public string GetReferralId(int chatId)
    {
        return ChatGroups.FirstOrDefault(c => c.Value == chatId).Key;
    }
}

