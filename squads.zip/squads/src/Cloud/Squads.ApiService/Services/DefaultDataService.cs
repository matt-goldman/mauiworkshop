﻿using Squads.ApiService.Models;
using Squads.ApiService.Persistence;
using Microsoft.EntityFrameworkCore;
using Polly;

namespace Squads.ApiService.Services;

public class DefaultDataService
{
    private readonly ApplicationDbContext _dbContext;
    private readonly TimeProvider _timeProvider;
    private readonly ILogger<DefaultDataService> _logger;
    private const string DefaultChatName = "Open forum";

    private const string _dataUrl = "https://starwars-databank-server.vercel.app/api/v1/characters";

    public DefaultDataService(ApplicationDbContext dbContext, TimeProvider timeProvider, ILogger<DefaultDataService> logger)
    {
        _dbContext = dbContext;
        _timeProvider = timeProvider;
        _logger = logger;
    }

    public async Task SeedDefaultData()
    {
        var policy = Policy.Handle<Exception>().WaitAndRetryAsync(
            5,
            retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)),
            (exception, timeSpan, retryCount, context) =>
            {
                _logger.LogWarning("Retry {retryCount} after {seconds} seconds", retryCount, timeSpan.TotalSeconds);
                _logger.LogError("Failed to migrate database: {exception}.", exception);
            });
        
        await policy.ExecuteAsync(() => _dbContext.Database.MigrateAsync());

        var defaultChat = await _dbContext.Chats.FindAsync(1);

        if (defaultChat is null)
        {
            defaultChat = new Chat
            {
                Name = DefaultChatName,
                CreatedAt = _timeProvider.GetUtcNow().UtcDateTime,
            };

            _dbContext.Chats.Add(defaultChat);
            await _dbContext.SaveChangesAsync();
        }
        else
        {
            if (defaultChat.Name != DefaultChatName)
                throw new InvalidOperationException("The default chat is invalid. You need to delete and re-seed your database.");
        }

        if (!await _dbContext.Users.AnyAsync(u => u.Email == "seeded@seed.seed"))
        {
            Console.WriteLine("Seeding users...");
            await SeedUsers();
        }
    }

    private async Task SeedUsers()
    {
        using var client = new HttpClient { BaseAddress = new Uri(_dataUrl) };

        var users = new List<Datum>();

        Console.WriteLine("Fetching users...");

        for (int i = 1; i <= 100; i++)
        {
            var data = await client.GetFromJsonAsync<Rootobject>($"?page={i}&limit=10");

            if (data is null)
                break;

            users.AddRange(data.data);
        }

        Console.WriteLine("Got users. Adding to database...");

        var randomUsers = users.OrderBy(x => Guid.NewGuid()).Take(50);
        var skywalkers = users.Where(x => x.name.ToLower().Contains("skywalker")).OrderBy(x => Guid.NewGuid()).Take(3);
        randomUsers = randomUsers.Concat(skywalkers);

        foreach (var user in randomUsers)
        {
            if (user.name.Contains("\""))
                continue;

            var names = user.name.Split(" ");

            if (names.Length < 2)
                continue;

            var concatName = string.Join("", names);
            var email = $"{concatName}@starwars.com";
            var upperEmail = email.ToUpper();

            var dbUser = new AppUser
            {
                UserName = email,
                NormalizedUserName = upperEmail,
                Email = email,
                NormalizedEmail = upperEmail,
                Firstname = names[0],
                Lastname = names[1],
                ProfilePictureUrl = user.image
            };

            _dbContext.Users.Add(dbUser);
        }

        var seedMarker = new AppUser
        {
            Email = "seeded@seed.seed"
        };

        _dbContext.Users.Add(seedMarker);

        await _dbContext.SaveChangesAsync();

        Console.WriteLine("Done seeding users.");
    }
}

public class Rootobject
{
    public Info info { get; set; }
    public Datum[] data { get; set; }
}

public class Info
{
    public int total { get; set; }
    public int page { get; set; }
    public int limit { get; set; }
    public string next { get; set; }
    public string prev { get; set; }
}

public class Datum
{
    public string _id { get; set; }
    public string name { get; set; }
    public string description { get; set; }
    public string image { get; set; }
    public int __v { get; set; }
}
