﻿using Squads.ApiService.Extensions;
using Squads.ApiService.Services;
using Microsoft.AspNetCore.Mvc;

namespace Squads.ApiService.Endpoints;

public static class ImageEndpoints
{
    public static void MapImageEndpoints(this WebApplication app)
    {
        var group = app
            .MapApiGroup("images");

        group
            .MapGet("/{id}", async (string id, [FromServices] IStorageService storageService) =>
            {
                var stream = new MemoryStream();
                
                await storageService.GetPictureAsync(id, stream);

                stream.Position = 0;

                return Results.Stream(stream, "image/jpeg");
            })
            .ProducesGet<FileStreamResult>();
    }
}
