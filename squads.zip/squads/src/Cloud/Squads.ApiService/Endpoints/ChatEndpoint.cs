﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Squads.ApiService.Exceptions;
using Squads.ApiService.Extensions;
using Squads.ApiService.Services;
using Squads.Shared.DTOs;

namespace Squads.ApiService.Endpoints;

public static class ChatEndpoint
{
    public static void MapChatEndpoints(this WebApplication app)
    {
        var group = app
            .MapApiGroup("chats")
            .RequireAuthorization();

        group
            .MapGet("/", async (
                CancellationToken cancellationToken,
                [FromServices] IChatService chatService,
                [FromServices] IMapper mapper) =>
            {
                var chats = await chatService.GetMyChats(cancellationToken);

                return mapper.Map<List<ChatDto>>(chats);
            })
            .ProducesGet<List<ChatDto>>();

        group
            .MapGet("/{referralId}", async (
                CancellationToken cancellationToken,
                string referralId,
                [FromServices] IChatService chatService,
                [FromServices] IMapper mapper) =>
            {
                var messages = await chatService.GetChat(referralId, cancellationToken, true);

                return mapper.Map<ChatDto>(messages);
            })
            .ProducesGet<ChatDto>();

        group
            .MapPost("/query", async (
                CancellationToken cancellationToken,
                [FromQuery] bool? includeMessages,
                [FromBody] List<string> userIds,
                [FromServices] IChatService chatService,
                [FromServices] IMapper mapper) =>
            {
                try
                {
                    var chat = await chatService.GetChat(userIds, cancellationToken, includeMessages??false);

                    return Results.Ok(mapper.Map<ChatDto>(chat));
                }
                catch (NotFoundException)
                {
                    return Results.NotFound();
                }
            })
            .Produces<ChatDto>(StatusCodes.Status200OK)
            .Produces(StatusCodes.Status404NotFound);

        group
            .MapPost("/", async (
                CancellationToken cancellationToken,
                [FromServices] IChatService chatService,
                [FromBody] CreateChatPayload payload) =>
            {
                var (referralId, id) = await chatService.CreateChat(payload.Name, payload.UserIds, cancellationToken);
                return referralId;
            })
            .Produces<string>(StatusCodes.Status201Created);
    }
}

public class CreateChatPayload
{
    public List<string> UserIds { get; set; } = [];
    public string Name { get; set; }
}
