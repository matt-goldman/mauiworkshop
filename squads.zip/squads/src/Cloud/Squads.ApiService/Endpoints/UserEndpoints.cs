﻿using Squads.ApiService.Extensions;
using Squads.ApiService.Services;
using Microsoft.AspNetCore.Mvc;
using Squads.Shared.DTOs;

namespace Squads.ApiService.Endpoints;

public static class UserEndpoints
{
    public static void MapUserEndpoints(this WebApplication app)
    {
        var group = app
            .MapApiGroup("users")
            .RequireAuthorization();


        group
            .MapGet("/", async (CancellationToken cancellationToken, [FromServices] IUserService userService) =>
            {
                return await userService.GetMyProfile(cancellationToken);
            })
            .ProducesGet<UserProfileDto>();

        group
            .MapGet("/all", async (CancellationToken cancellationToken, int page, int pageSize, [FromServices] IUserService userService) =>
            {
                return await userService.GetUsers(page, pageSize, cancellationToken);
            })
            .ProducesGet<List<UserProfileDto>>();

        group
            .MapGet("/{id}", async (CancellationToken cancellationToken, string id, [FromServices] IUserService userService) =>
            {
                return await userService.GetUser(id, cancellationToken);
            })
            .ProducesGet<UserProfileDto>();

        group
            .MapPost("/profilepicture", async (CancellationToken cancellationToken, [FromBody] Stream file, [FromServices] IUserService userService) =>
            {
                await userService.UploadProfilePicture(file, cancellationToken);
            })
            .ProducesPost();

        group
            .MapPut("/", async (CancellationToken cancellationToken, UserProfileDto user, [FromServices] IUserService userService) =>
            {
                return await userService.UpsertMyProfile(user, cancellationToken);
            })
            .Produces<UserProfileDto>(StatusCodes.Status200OK);

        group
            .MapGet("/search/{query}", async (CancellationToken cancellationToken, string query, [FromQuery] int pageSize, [FromQuery] int page, [FromServices] IUserService userService) =>
            {
                return await userService.SearchUser(query, page, pageSize, cancellationToken);
            })
            .ProducesGet<List<UserProfileDto>>();
    }
}
