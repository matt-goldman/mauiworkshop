﻿using Squads.ApiService.Models;
using AutoMapper;
using Squads.Shared.DTOs;
using System.Security.Claims;

namespace Squads.ApiService.Mappings;

public class CurrentUserIdResolver : IValueResolver<UserChat, UserProfileDto, bool>
{
    private readonly IHttpContextAccessor _httpContextAccessor;

    public CurrentUserIdResolver(IHttpContextAccessor httpContextAccessor)
    {
        _httpContextAccessor = httpContextAccessor;
    }

    public bool Resolve(UserChat source, UserProfileDto destination, bool destMember, ResolutionContext context)
    {
        var myId = _httpContextAccessor.HttpContext?.User?.FindFirstValue(ClaimTypes.NameIdentifier);

        if (myId == null)
        {
            return false;
        }

        return myId == source.UserId;
    }
}
