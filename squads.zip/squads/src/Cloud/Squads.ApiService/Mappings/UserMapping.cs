﻿using Squads.ApiService.Models;
using AutoMapper;
using Squads.Shared.DTOs;

namespace Squads.ApiService.Mappings;

public class UserMapping : Profile
{
    public UserMapping()
    {
        CreateMap<UserChat, UserProfileDto>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.User.Id))
            .ForMember(dest => dest.FirstName, opt => opt.MapFrom(src => src.User.Firstname))
            .ForMember(dest => dest.LastName, opt => opt.MapFrom(src => src.User.Lastname))
            .ForMember(dest => dest.ProfilePictureUrl, opt => opt.MapFrom(src => src.User.ProfilePictureUrl))
            .ForMember(dest => dest.Email, opt => opt.MapFrom(src => src.User.Email))
            .ForMember(dest => dest.IsMe, opt => opt.MapFrom<CurrentUserIdResolver>())
            .ForMember(dest => dest.ProfileComplete, opt => opt.Ignore());
    }
}
