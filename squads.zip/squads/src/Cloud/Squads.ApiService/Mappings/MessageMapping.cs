﻿using Squads.ApiService.Models;
using AutoMapper;
using Squads.Shared.Messages;

namespace Squads.ApiService.Mappings;

public class MessageMapping : Profile
{
    public MessageMapping()
    {
        CreateMap<Message, ChatMessage>()
            .ForMember(dst => dst.Message, opt => opt.MapFrom(src => src.Content))
            .ForMember(dst => dst.SentUtc, opt => opt.MapFrom(src => src.CreatedAt))
            .ForMember(dst => dst.SenderName, opt => opt.MapFrom(src => src.Sender.Fullname))
            .ForMember(dst => dst.SenderPicUrl, opt => opt.MapFrom(src => src.Sender.ProfilePictureUrl));
    }
}
