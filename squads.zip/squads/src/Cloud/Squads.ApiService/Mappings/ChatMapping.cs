﻿using Squads.ApiService.Models;
using AutoMapper;
using Squads.Shared.DTOs;

namespace Squads.ApiService.Mappings;

public class ChatMapping : Profile
{
    public ChatMapping()
    {
        CreateMap<Chat, ChatDto>()
            .ForMember(dst => dst.Users, opt => opt.MapFrom(src => src.UserChats));
    }
}
