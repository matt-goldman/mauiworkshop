using Azure.Core;
using Azure.Identity;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Npgsql;
using Scalar.AspNetCore;
using Squads.ApiService.Endpoints;
using Squads.ApiService.Hubs;
using Squads.ApiService.Mappings;
using Squads.ApiService.Models;
using Squads.ApiService.Persistence;
using Squads.ApiService.Services;
using Squads.Constants;
using System.Reflection;

var builder = WebApplication.CreateBuilder(args);

// Add service defaults & Aspire client integrations.
builder.AddServiceDefaults();

// Add services to the container.
builder.Services.AddProblemDetails();

// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
builder.Services.AddOpenApi();

builder.AddAzureBlobClient(ServiceConstants.PROFILE_BLOB);

builder.Services.AddAuthentication().AddBearerToken(IdentityConstants.BearerScheme);
builder.Services.AddAuthorizationBuilder();

//builder.AddNpgsqlDbContext<ApplicationDbContext>(ServiceConstants.SQUADS_DATABASE);

//builder.AddNpgsqlDbContext<ApplicationDbContext>(
builder.AddNpgsqlDataSource(
    ServiceConstants.SQUADS_DATABASE,
    configureDataSourceBuilder: (dataSourceBuilder) =>
    {
        if (!string.IsNullOrEmpty(dataSourceBuilder.ConnectionStringBuilder.Password))
        {
            return;
        }

        dataSourceBuilder.UsePeriodicPasswordProvider(async (_, ct) =>
        {
            var credentials = new DefaultAzureCredential();
            var token = await credentials.GetTokenAsync(
                new TokenRequestContext([
                    "https://ossrdbms-aad.database.windows.net/.default"
                ]), ct);

            return token.Token;
        },
        TimeSpan.FromHours(24),
        TimeSpan.FromSeconds(10));
    });

builder.Services.AddDbContext<ApplicationDbContext>((serviceProvider, options) =>
{
    var dataSource = serviceProvider.GetRequiredService<NpgsqlDataSource>();
    options.UseNpgsql(dataSource);
});

builder.Services.AddIdentityCore<AppUser>()
    .AddEntityFrameworkStores<ApplicationDbContext>()
    .AddApiEndpoints();

builder.Services.AddSignalR();

builder.Services.AddHttpContextAccessor();

builder.Services.AddScoped<IUserService, UserService>();
builder.Services.AddScoped<IChatService, ChatService>();
builder.Services.AddScoped<IStorageService, AzureStorageService>();
builder.Services.AddSingleton<IUserConnectionManager, UserConnectionManager>();
builder.Services.AddTransient<CurrentUserIdResolver>();

builder.Services.AddScoped<DefaultDataService>();

builder.Services.AddAutoMapper(Assembly.GetExecutingAssembly());

var app = builder.Build();

using var scope = app.Services.CreateScope();
var seeder = scope.ServiceProvider.GetRequiredService<DefaultDataService>();
await seeder.SeedDefaultData();


app.MapIdentityApi<AppUser>();

// Configure the HTTP request pipeline.
app.UseExceptionHandler();

//if (app.Environment.IsDevelopment())
//{
//    app.MapOpenApi();
//    app.MapScalarApiReference(opt =>
//    {
//        opt.Theme = ScalarTheme.Purple;

//        // OpenAPI generator ignores forward headers, so the generated doc
//        // lists the random Aspire app host ports, not the proxy port.
//        // Overriding the servers array with an empty one forces Scalar
//        // to point at the host instead.
//        opt.Servers = [];
//    });
//}

app.MapOpenApi();
app.MapScalarApiReference(opt =>
{
    opt.Theme = ScalarTheme.Purple;

    // OpenAPI generator ignores forward headers, so the generated doc
    // lists the random Aspire app host ports, not the proxy port.
    // Overriding the servers array with an empty one forces Scalar
    // to point at the host instead.
    opt.Servers = [];
});

app.UseHttpsRedirection();


app.UseAuthentication();
app.UseAuthorization();


app.MapUserEndpoints();
app.MapImageEndpoints();
app.MapChatEndpoints();


app.MapHub<ChatHub>("/chat");

app.MapDefaultEndpoints();

app.Run();
