﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Squads.Shared.DTOs;

namespace Squads.UI.ViewModels;

public partial class ProfileViewModel(
    IUserService userService,
    IAlertService alertService,
    INavigationService navigationService) : ObservableObject
{
    [ObservableProperty]
    private UserProfileViewModel userProfile;

    [ObservableProperty]
    private bool isRunning;

    [ObservableProperty]
    private string formTitle;

    [ObservableProperty]
    private double overlayOpacity;

    [ObservableProperty]
    private bool isExpanded;

    [ObservableProperty]
    private bool isEditable;

    [ObservableProperty]
    private bool isEditing;

    public ProfileViewModel(
      IUserService userService,
      IAlertService alertService,
      INavigationService navigationService,
      UserProfileDto user) : this(userService, alertService, navigationService)
    {
        UserProfile = new UserProfileViewModel(user);
    }

    public async Task Init()
    {
        IsRunning = true;
        OverlayOpacity = 0.5;
        if (UserProfile is null)
        {
            var profile = await userService.GetMyProfileAsync();
            UserProfile = new UserProfileViewModel(profile);
            IsEditable = UserProfile.IsMe;
        }

        if (UserProfile.IsMe)
        {
            if (!UserProfile.ProfileComplete)
            {
                FormTitle = "Complete your profile";
            }
            else
            {
                FormTitle = "Edit your profile";
            }
        }
        else
        {
            FormTitle = string.Empty;
        }

        IsRunning = false;
    }

    [RelayCommand]
    public async Task SaveProfile()
    {
        IsRunning = true;
        OverlayOpacity = 0.5;

        var succeeded = await userService.UpdateProfileAsync(UserProfile.ToDto());

        if (succeeded)
        {
            await alertService.DisplayAlert("Success", "Profile updated successfully");
            var profile = await userService.GetMyProfileAsync();
            UserProfile = new UserProfileViewModel(profile);
        }
        else
        {
            await alertService.DisplayAlert("Error", $"Something went wrong");
        }

        IsRunning = false;
        IsEditing = false;
        IsEditable = true;
    }

    private async Task UploadPicture(FileResult photo)
    {
        IsRunning = true;
        OverlayOpacity = 0.5;

        var stream = await photo.OpenReadAsync();
        await userService.UploadProfilePhotoAsync(stream);
        var profile = await userService.GetMyProfileAsync();
        profile.FirstName = UserProfile.FirstName;
        profile.LastName = UserProfile.LastName;
        UserProfile = new UserProfileViewModel(profile);

        IsRunning = false;
    }

    [RelayCommand]
    public async Task TakePhoto()
    {
        if (MediaPicker.Default.IsCaptureSupported)
        {
            try
            {
                var photo = await MediaPicker.Default.CapturePhotoAsync();

                if (photo != null)
                {
                    await UploadPicture(photo);
                }
            }
            catch (PermissionException)
            {
                await alertService.DisplayAlert("Permissions error", "You must grant the app permission to use the camera.");
            }
        }
        else
        {
            await alertService.DisplayAlert("Error", "Camera not supported");
        }

        IsExpanded = false;
    }

    [RelayCommand]
    public async Task PickPhoto()
    {
        if (MediaPicker.Default.IsCaptureSupported)
        {
            try
            {
                var photo = await MediaPicker.Default.PickPhotoAsync();

                if (photo != null)
                {
                    await UploadPicture(photo);
                }
            }
            catch (PermissionException)
            {
                await alertService.DisplayAlert("Permissions error", "You must grant the app permissions to use the gallery.");
            }
        }
        else
        {
            await alertService.DisplayAlert("Error", "Photos not supported");
        }

        IsExpanded = false;
    }

    [RelayCommand]
    public void Edit()
    {
        IsEditing = true;
        IsEditable = false;
    }

    [RelayCommand]
    public async Task Chat()
    {
        var args = new Dictionary<string, object>
        {
            { "user", UserProfile.Id }
        };

        await navigationService.GoToAsync($"Chat/{nameof(ChatPage)}", args);
    }
    
    [RelayCommand]
    public async Task GoBack()
    {
        await navigationService.PopModalAsync();
    }
}
