﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System.Collections.ObjectModel;

namespace Squads.UI.ViewModels;

public partial class PeopleViewModel(IUserService userService, INavigationService navigationService) : ObservableObject
{
    public ObservableCollection<UserProfileViewModel> Users { get; set; } = new();

    [ObservableProperty]
    bool isRunning;

    public async Task Init()
    {
        IsRunning = true;

        var users = await userService.GetUsers();

        foreach (var user in users)
        {
            Users.Add(new UserProfileViewModel(user));
        }

        IsRunning = false;
    }

    [RelayCommand]
    public async Task ViewUser(UserProfileViewModel user)
    {
        await navigationService.PushModalAsync<ProfilePage>(user.ToDto());
    }
}