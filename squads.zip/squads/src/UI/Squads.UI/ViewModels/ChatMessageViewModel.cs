using Squads.Shared.Messages;

namespace Squads.UI.ViewModels;

public class ChatMessageViewModel
{
    public string SenderName { get; set; }
    public string Content { get; set; }
    public bool IsMyMessage { get; set; }
    public string Initials { get; set; }
    public string? ProfilePicUrl { get; set; }
    public DateTime SentAt { get; set; }

    public int MessageId { get; set; }

    public ChatMessageViewModel(ChatMessage message, string myId)
    {
        SenderName = message.SenderName;
        Content = message.Message;
        IsMyMessage = message.SenderId == myId;
        ProfilePicUrl = string.IsNullOrWhiteSpace(message.SenderPicUrl) ? null : message.SenderPicUrl;
        Initials = GetInitials(message.SenderName);
        SentAt = message.SentUtc;
        MessageId = message.Id;
    }

    private string GetInitials(string name)
    {
        var initials = name.Split(' ').Select(n => n[0]);
        return string.Join("", initials);
    }
}