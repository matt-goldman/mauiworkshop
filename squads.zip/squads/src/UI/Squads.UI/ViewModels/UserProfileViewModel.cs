﻿using Maui.Plugins.PageResolver.Attributes;
using Squads.Shared.DTOs;

namespace Squads.UI.ViewModels;

public class UserProfileViewModel
{
    public UserProfileViewModel(UserProfileDto userProfile)
    {
        Id = userProfile.Id;
        FirstName = userProfile.FirstName;
        LastName = userProfile.LastName;
        FullName = userProfile.FullName;
        ProfilePictureUrl = userProfile.ProfilePictureUrl.TunneliseUrl();
        Email = userProfile.Email;
        IsMe = userProfile.IsMe;
        ProfileComplete = userProfile.ProfileComplete;

        if (!string.IsNullOrWhiteSpace(FirstName) && !string.IsNullOrWhiteSpace(LastName))
        {
            Initials = $"{FirstName[0]}{LastName[0]}";
        }
    }

    public string Id { get; set; } = string.Empty;

    public string FirstName { get; set; } = string.Empty;

    public string LastName { get; set; } = string.Empty;

    public string FullName { get; set; } = string.Empty;

    public string Initials { get; set; } = string.Empty;

    public string? ProfilePictureUrl { get; set; }

    public string Email { get; set; } = string.Empty;

    public bool IsMe { get; set; } = false;

    public bool ProfileComplete { get; set; } = false;

    public UserProfileDto ToDto()
    {
        return new UserProfileDto
        {
            Id = Id,
            FirstName = FirstName,
            LastName = LastName,
            ProfilePictureUrl = string.IsNullOrWhiteSpace(ProfilePictureUrl) ? string.Empty : ProfilePictureUrl,
            Email = Email
        };
    }
}