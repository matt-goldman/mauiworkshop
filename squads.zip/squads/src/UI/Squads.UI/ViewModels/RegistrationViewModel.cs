using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace Squads.UI.ViewModels;

public partial class RegistrationViewModel(
    IAuthenticationService authenticationService,
    INavigationService navigationService,
    IAlertService alertService) : ObservableObject
{
    [ObservableProperty]
    private RegisterModel registerModel = new();

    [ObservableProperty]
    private bool isRunning;

    [ObservableProperty]
    private double overlayOpacity;

    [RelayCommand]
    private async Task Register()
    {
        IsRunning = true;
        OverlayOpacity = 0.5;

        var response = await authenticationService.Register(RegisterModel);

        if (response)
        {
            await navigationService.PopModalAsync();
        }
        else
        {
            IsRunning = false;

            await alertService.DisplayAlert("Error", "Registration failed");
        }
    }
}
