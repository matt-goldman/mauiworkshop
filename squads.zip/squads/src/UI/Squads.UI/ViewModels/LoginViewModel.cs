using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace Squads.UI.ViewModels;

public partial class LoginViewModel(
    IAuthenticationService authenticationService,
    INavigationService navigationService,
    IAlertService alertService) : ObservableObject
{
    [ObservableProperty]
    private bool isRunning;

    [ObservableProperty]
    private double overlayOpacity;

    [ObservableProperty]
    private LoginModel loginModel = new();

    [RelayCommand]
    private async Task Signup()
    {
        await navigationService.PushModalAsync<RegistrationPage>();
    }

    [RelayCommand]
    private async Task Login()
    {
        IsRunning = true;
        OverlayOpacity = 0.5;

        var response = await authenticationService.Login(LoginModel);

        if (response)
        {
            navigationService.GoToRoot();
        }
        else
        {
            IsRunning = false;

            await alertService.DisplayAlert("Error", "Login failed");
        }
    }

    public async Task Init()
    {
        IsRunning = true;
        OverlayOpacity = 0.5;

        var response = await authenticationService.RefreshToken();

        IsRunning = false;

        if (response)
        {
            navigationService.GoToRoot();
        }
    }
}
