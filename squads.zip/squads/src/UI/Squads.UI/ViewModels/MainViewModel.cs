using CommunityToolkit.Mvvm.ComponentModel;
using Microsoft.AspNetCore.SignalR.Client;
using Squads.Shared.Messages;
using Squads.Shared;
using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.Input;
using Squads.Shared.DTOs;

namespace Squads.UI.ViewModels;

public partial class MainViewModel : ObservableObject
{
    public ObservableCollection<ChatMessageViewModel> Messages { get; set; } = new();

    [ObservableProperty]
    string messageText;

    private HubConnection? _hubConnection;

    private readonly IUserService _userService;
    private readonly INavigationService _navigationService;

    private UserProfileDto _myProfile;

    public MainViewModel(IUserService userService, IAuthenticationService authService, INavigationService navigationService)
    {
        _hubConnection = new HubConnectionBuilder()
            .WithUrl($"{App.ApiUri}chat", options =>
            {
                options.AccessTokenProvider = async () => await authService.GetAccessToken();
            })
            .Build();

        _userService = userService;
        _navigationService = navigationService;
    }

    public async Task Init()
    {
        _myProfile = await _userService.GetMyProfileAsync();

        if (!_myProfile.ProfileComplete)
        {
            await _navigationService.GoToAsync("//ProfilePage");
        }
        else if (_hubConnection.State == HubConnectionState.Disconnected)
        {
            _hubConnection.On<ChatMessage>(MessageConstants.RECEIVE, message =>
            {
                message.SenderPicUrl = message.SenderPicUrl.TunneliseUrl();
                Messages.Add(new(message, _myProfile.Id));
                Vibration.Default.Vibrate();
            });

            await _hubConnection.StartAsync();
        }
    }

    [RelayCommand]
    public async Task SendMessage()
    {
        var message = new ChatMessage
        {
            Message = MessageText
        };

        await _hubConnection.SendAsync(MessageConstants.SEND, message);
        MessageText = string.Empty;
    }
}