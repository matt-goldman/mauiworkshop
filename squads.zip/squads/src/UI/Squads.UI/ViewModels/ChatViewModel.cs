﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.AspNetCore.SignalR.Client;
using Squads.Shared.DTOs;
using Squads.Shared;
using System.Collections.ObjectModel;
using Squads.Shared.Messages;

namespace Squads.UI.ViewModels;

public partial class ChatViewModel : ObservableObject, IQueryAttributable
{
    public void ApplyQueryAttributes(IDictionary<string, object> query)
    {
        CreateNewChat = false;

        if (query.TryGetValue("newChat", out var newChat))
        {
            CreateNewChat = true;
            return;
        }

        if (query.TryGetValue("referralId", out var referralId))
        {
            this.referralId = referralId.ToString();
            return;
        }

        if (query.TryGetValue("user", out var userId))
        {
            ChatUserIds.Add(userId.ToString());
            return;
        }

        if (query.TryGetValue("userIds", out var userIds))
        {
            var userIdsList = userIds.ToString()?.Split(',').ToList();
            userIdsList?.ForEach(id => ChatUserIds.Add(id));
        }
    }

    private readonly IChatService _chatService;
    private readonly IUserService _userService;

    public ObservableCollection<ChatMessageViewModel> Messages { get; set; } = [];
    public ObservableCollection<string> ChatUserIds { get; set; } = [];
    public ObservableCollection<object> SelectedUsers { get; set; } = [];


    [ObservableProperty]
    string messageText;

    [ObservableProperty]
    private bool isRunning;

    [ObservableProperty]
    private string title;

    [ObservableProperty]
    private bool _createNewChat;
    
    public event EventHandler ChatCreated;

    public bool IsNewChatEnabled => SelectedUsers.Count > 0;

    // TODO: get rid of this eventually
    // see: https://github.com/dotnet/maui/issues/18234
    [ObservableProperty]
    private double overlayOpacity;

    private int _chatId;

    private string referralId;

    private HubConnection _hubConnection;

    private UserProfileDto myProfile;

    public ChatViewModel(
        IAuthenticationService authService,
        IChatService chatService,
        IUserService userService)
    {
        _hubConnection = new HubConnectionBuilder()
            .WithUrl($"{App.ApiUri}chat", options =>
            {
                options.AccessTokenProvider = async () => await authService.GetAccessToken();
            })
            .Build();

        _chatService = chatService;
        _userService = userService;
    }


    public ObservableCollection<UserProfileViewModel> SearchResults { get; set; } = new();

    [RelayCommand]
    public async Task Search(string searchText)
    {
        SearchResults.Clear();

        var results = await _userService.SearchUsers(searchText);

        foreach (var result in results)
        {
            SearchResults.Add(new UserProfileViewModel(result));
        }
    }

    public async Task Init(string referralId)
    {
        this.referralId = referralId;
        Messages.Clear();
        await Init();
    }
    
    public void InitNew()
    {
        referralId = string.Empty;
        SelectedUsers.Clear();
        SearchResults.Clear();
        ChatUserIds.Clear();
        Messages.Clear();
        CreateNewChat = true;
    }

    public async Task Init()
    {
        if (CreateNewChat)
        {
            return;
        }

        IsRunning = true;

        if (_hubConnection.State == HubConnectionState.Disconnected)
        {
            await _hubConnection.StartAsync();
        }

        myProfile = await _userService.GetMyProfileAsync();

        var chat = new ChatDto();

        if (!string.IsNullOrEmpty(referralId))
        {
            chat = await _chatService.GetChat(referralId);
        }
        else
        {
            chat = await _chatService.GetChat(ChatUserIds.ToList());

            ChatUserIds.Add(myProfile.Id);
        }

        if (chat.Id == -1)
        {
            _hubConnection.On<ChatMessage>(MessageConstants.RECEIVE, async message =>
            {
                if (message.SenderName == "System" && message.Message.EndsWith("has been created"))
                {
                    chat = await _chatService.GetChat(ChatUserIds.ToList());
                    UpdateMessages(chat);
                    
                    MainThread.BeginInvokeOnMainThread(() =>
                    {
                        if (!OrientationHelper.IsInPortraitMode)
                        {
                            ChatCreated?.Invoke(this, EventArgs.Empty);
                        }
                    });
                }
            });

            await _hubConnection.SendAsync(MessageConstants.CREATE, string.Empty, ChatUserIds);
        }
        else
        {
            UpdateMessages(chat);

            await _hubConnection.SendAsync(MessageConstants.JOIN, chat.ReferralId);
        }

        _hubConnection.On<ChatMessage>(MessageConstants.RECEIVE, message =>
        {
            if (message.ChatId == _chatId && Messages.All(m => m.MessageId != message.Id))
            {
                message.SenderPicUrl = message.SenderPicUrl.TunneliseUrl();
                Messages.Add(new(message, myProfile.Id));
                Vibration.Default.Vibrate();
            }
        });

        IsRunning = false;
    }

    private void UpdateMessages(ChatDto chat)
    {
        Title = chat.Name;
        _chatId = chat.Id;

        foreach (var message in chat.Messages)
        {
            if (Messages.Any(m => m.MessageId == message.Id))
                continue;

            message.SenderPicUrl = message.SenderPicUrl.TunneliseUrl();
            Messages.Add(new(message, myProfile.Id));
        }
    }

    [RelayCommand]
    public async Task SendMessage()
    {
        var message = new ChatMessage
        {
            ChatId = _chatId,
            Message = MessageText
        };

        await _hubConnection.SendAsync(MessageConstants.SEND, message);
        MessageText = string.Empty;
    }

    [RelayCommand]
    public void RemoveUser(UserProfileViewModel user)
    {
        SelectedUsers.Remove(user);
    }

    [RelayCommand]
    public void SelectedUsersChanged(IList<object> selectedUsers)
    {
        OnPropertyChanged(nameof(IsNewChatEnabled));
    }

    [RelayCommand]
    public async Task CreateChat()
    {
        foreach (UserProfileViewModel user in SelectedUsers)
        {
            ChatUserIds.Add(user.Id);
        }

        CreateNewChat = false;

        await Init();
    }

    public async Task Dispose()
    {
        await _hubConnection.StopAsync();
    }
}
