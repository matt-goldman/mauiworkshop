using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Squads.Shared.DTOs;
using System.Collections.ObjectModel;

namespace Squads.UI.ViewModels;

public partial class ChatListViewModel(IChatService chatService, INavigationService navigationService)
    : ObservableObject
{
    public ObservableCollection<ChatDto> Chats { get; set; } = [];

    public event EventHandler<string> ChatSelected;
    
    public event EventHandler NewChatSelected;

    [ObservableProperty]
    private bool isRunning;

    public async Task Init()
    {
        if (IsRunning) return;

        IsRunning = true;

        var chats = await chatService.GetChats();

        Chats.Clear();
        foreach (var chat in chats)
        {
            Chats.Add(chat);
        }

        IsRunning = false;
    }

    [RelayCommand]
    public async Task OpenChat(ChatDto chat)
    {
        if (OrientationHelper.IsInPortraitMode)
        {
            var args = new Dictionary<string, object>
            {
                { "referralId", chat.ReferralId }
            };

            await navigationService.GoToAsync($"Chat/{nameof(ChatPage)}", args);
        }
        else
        {
            ChatSelected?.Invoke(this, chat.ReferralId.ToString());
        }
    }

    [RelayCommand]
    public async Task NewChat()
    {
        if (OrientationHelper.IsInPortraitMode)
        {
            var args = new Dictionary<string, object>
            {
                { "newChat", true }
            };

            await navigationService.GoToAsync($"Chat/{nameof(ChatPage)}", args);
        }
        else
        {
            NewChatSelected?.Invoke(this, EventArgs.Empty);
        }
    }
    
    [RelayCommand]
    public async Task Refresh()
    {
        IsRunning = true;

        var chats = await chatService.GetChats();

        var chatsToAdd = chats.Where(c => Chats.All(nc => nc.ReferralId != c.ReferralId)).ToList();
        foreach (var chat in chatsToAdd)
        {
            Chats.Add(chat);
        }

        IsRunning = false;
    }
}
