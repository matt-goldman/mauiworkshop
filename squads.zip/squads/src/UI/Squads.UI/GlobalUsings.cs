global using Squads.UI.Pages;
global using Squads.UI.Helpers;
global using Squads.UI.Services;
global using System.Net.Http.Json;
global using Maui.Plugins.PageResolver;