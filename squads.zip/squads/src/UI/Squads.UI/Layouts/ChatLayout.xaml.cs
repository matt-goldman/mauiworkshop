namespace Squads.UI.Layouts;

public partial class ChatLayout : ContentView
{
	public ChatLayout()
	{
		InitializeComponent();
	}
}