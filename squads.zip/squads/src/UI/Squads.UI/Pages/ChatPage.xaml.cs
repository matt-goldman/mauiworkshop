using Squads.UI.ViewModels;

namespace Squads.UI.Pages;

public partial class ChatPage : ContentPage
{
    private readonly ChatViewModel _viewModel;

    public ChatPage(ChatViewModel ViewModel)
    {
        InitializeComponent();
        _viewModel = ViewModel;
        BindingContext = _viewModel;
    }

    protected override async void OnNavigatedTo(NavigatedToEventArgs args)
    {
        await _viewModel.Init();
        base.OnNavigatedTo(args);
    }

    protected override async void OnNavigatedFrom(NavigatedFromEventArgs args)
    {
        await _viewModel.Dispose();
        base.OnNavigatedFrom(args);
    }
}