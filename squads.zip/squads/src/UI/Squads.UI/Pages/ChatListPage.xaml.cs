using Squads.UI.ViewModels;

namespace Squads.UI.Pages;

public partial class ChatListPage : ContentPage
{
    public ChatListViewModel ViewModel { get; set; }
    public ChatViewModel? ChatViewModel { get; set; }

    public ChatListPage(ChatListViewModel viewModel, ChatViewModel chatViewModel)
    {
        InitializeComponent();
        ViewModel = viewModel;
        BindingContext = ViewModel;

        if (DeviceInfo.Current.Idiom == DeviceIdiom.Tablet || DeviceInfo.Current.Idiom == DeviceIdiom.Desktop)
        {
            ChatViewModel = chatViewModel;
            Messages.BindingContext = ChatViewModel;
        }
        
        if (DeviceInfo.Current.Idiom == DeviceIdiom.Tablet)
        {
            this.SizeChanged += OnSizeChanged;
        }
    }
    
    private void OnCreateChatSelected(object sender, EventArgs e)
    {
        ChatViewModel.InitNew();
    }
    
    public void OnSizeChanged(object? sender, EventArgs e)
    {
        if (this.Width > this.Height)
        {
            VisualStateManager.GoToState(LayoutGrid, "Landscape");
            VisualStateManager.GoToState(DetailGrid, "Landscape");
        }
        else
        {
            VisualStateManager.GoToState(LayoutGrid, "Portrait");
            VisualStateManager.GoToState(DetailGrid, "Portrait");
        }
    }

    protected override async void OnNavigatedTo(NavigatedToEventArgs args)
    {
        base.OnNavigatedTo(args);
        await ViewModel.Init();

        if (DeviceInfo.Current.Idiom == DeviceIdiom.Tablet || DeviceInfo.Current.Idiom == DeviceIdiom.Desktop)
        {
            ViewModel.ChatSelected += OnChatSelected;
            ViewModel.NewChatSelected += OnCreateChatSelected;
            ChatViewModel.ChatCreated += OnChatCreated;
        }
    }

    protected override async void OnNavigatedFrom(NavigatedFromEventArgs args)
	{
		base.OnNavigatedFrom(args);
        if (DeviceInfo.Current.Idiom == DeviceIdiom.Tablet || DeviceInfo.Current.Idiom == DeviceIdiom.Desktop)
		{
			ViewModel.ChatSelected -= OnChatSelected;
            ViewModel.NewChatSelected -= OnCreateChatSelected;
            ChatViewModel.ChatCreated -= OnChatCreated;
		}
	}

    private async void OnChatSelected(object sender, string referralId)
    {
        await ChatViewModel.Init(referralId);
    }
    
    private async void OnChatCreated(object? sender, EventArgs e)
    {
        await ViewModel.Refresh();
    }
}
