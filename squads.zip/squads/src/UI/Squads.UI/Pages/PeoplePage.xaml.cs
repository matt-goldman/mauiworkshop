using Squads.UI.ViewModels;

namespace Squads.UI.Pages;

public partial class PeoplePage : ContentPage
{
    private readonly PeopleViewModel ViewModel;

    public PeoplePage(PeopleViewModel viewModel)
    {
        InitializeComponent();
        ViewModel = viewModel;
        BindingContext = ViewModel;
    }

    protected override async void OnNavigatedTo(NavigatedToEventArgs args)
    {
        base.OnNavigatedTo(args);
        await ViewModel.Init();
    }
}