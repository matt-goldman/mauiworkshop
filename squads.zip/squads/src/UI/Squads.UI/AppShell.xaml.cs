﻿namespace Squads.UI;

public partial class AppShell : Shell
{
    public AppShell()
    {
        InitializeComponent();
        Routing.RegisterRoute($"Chat/{nameof(ChatPage)}", typeof(ChatPage));

        if (DeviceInfo.Current.Idiom == DeviceIdiom.Phone)
        {
            CurrentItem = PhoneTabs;
        }
    }

}
