﻿namespace Squads.UI;

public partial class App : Application
{
    public const string ApiUri = "https://api-service.salmonmoss-ad27fcd7.australiaeast.azurecontainerapps.io/";

    private readonly Page page;

    public App(LoginPage loginPage)
    {
        InitializeComponent();
        page = loginPage;
    }

    protected override Window CreateWindow(IActivationState? activationState)
    {
        return new Window(page);
    }
}
