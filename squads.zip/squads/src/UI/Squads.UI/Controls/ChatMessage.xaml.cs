using Squads.UI.ViewModels;
using Maui.BindableProperty.Generator.Core;

namespace Squads.UI.Controls;

public partial class ChatMessage : ContentView
{
    public ChatMessage()
    {
        InitializeComponent();
    }

    [AutoBindable(OnChanged = nameof(OnMessageChanged))]
    private ChatMessageViewModel message;
    private void OnMessageChanged(ChatMessageViewModel newValue)
    {
        BindingContext = newValue;
    }

    protected override void OnBindingContextChanged()
    {
        base.OnBindingContextChanged();
        MessageBubble.Opacity = 0;

        if (BindingContext is ChatMessageViewModel message && message.IsMyMessage)
        {
            MessageBubble.TranslationX = 100;
        }
        else
        {
            MessageBubble.TranslationX = -100;
        }

        MessageBubble.FadeTo(1, 500);
        MessageBubble.TranslateTo(0, 0, 500, Easing.SpringOut);
    }
}