using System.Windows.Input;
using Maui.BindableProperty.Generator.Core;

namespace Squads.UI.Controls;

public partial class RoundedSearchBar : ContentView
{
	public RoundedSearchBar()
	{
		InitializeComponent();
	}

    [AutoBindable]
    private ICommand _searchCommand;

    private CancellationTokenSource _cts;

    private void Entry_OnTextChanged(object sender, TextChangedEventArgs e)
    {
        if (_cts is { IsCancellationRequested: false })
        {
            _cts.Cancel();
        }

        _cts = new CancellationTokenSource();

        Task.Delay(TimeSpan.FromMilliseconds(500), _cts.Token)
            .ContinueWith(task =>
            {
                if (task.IsCanceled)
                {
                    return;
                }

                MainThread.BeginInvokeOnMainThread(() =>
                {
                    if (e.NewTextValue.Length > 0)
                    {
                        SearchCommand?.Execute(e.NewTextValue);
                    }
                });
            }, _cts.Token);
    }
}