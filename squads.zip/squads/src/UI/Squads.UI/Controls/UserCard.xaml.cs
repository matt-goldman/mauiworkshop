using Squads.UI.ViewModels;
using Maui.BindableProperty.Generator.Core;

namespace Squads.UI.Controls;

public partial class UserCard : ContentView
{
    public UserCard()
    {
        InitializeComponent();
    }

    [AutoBindable(OnChanged = nameof(UserChanged))]
    private UserProfileViewModel _user;
    private void UserChanged(UserProfileViewModel user)
    {
        UserProfile.BindingContext = user;
    }
}