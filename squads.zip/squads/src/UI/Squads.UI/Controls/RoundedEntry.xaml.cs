using Maui.BindableProperty.Generator.Core;
namespace Squads.UI.Controls;

public partial class RoundedEntry : ContentView
{
	public RoundedEntry()
	{
		InitializeComponent();
	}

    [AutoBindable(DefaultBindingMode = "TwoWay", OnChanged = nameof(TextPropertyChanged))]
    private string _text;
    private void TextPropertyChanged(string newValue)
    {
        if (Entry.Text != newValue)
        {
            Entry.Text = newValue;
        }
    }

    private void Entry_OnTextChanged(object sender, TextChangedEventArgs e)
    {
        if (Text != e.NewTextValue)
        {
            Text = e.NewTextValue;
        }
    }

    [AutoBindable(OnChanged = nameof(PlaceholderPropertyChanged))]
    private string placeholder;
    private void PlaceholderPropertyChanged(string newValue)
    {
        Entry.Placeholder = newValue;
    }

    [AutoBindable(OnChanged = nameof(IsPasswordPropertyChanged))]
    private bool isPassword;
    private void IsPasswordPropertyChanged(bool newValue)
    {
        Entry.IsPassword = newValue;
    }

    [AutoBindable(OnChanged = nameof(HorizontalTextAlignmentPropertyChanged))]
    private TextAlignment horizontalTextAlignment;
    private void HorizontalTextAlignmentPropertyChanged(TextAlignment newValue)
    {
        Entry.HorizontalTextAlignment = newValue;
    }
}