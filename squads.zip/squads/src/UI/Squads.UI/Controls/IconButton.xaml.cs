using Maui.BindableProperty.Generator.Core;
using System.Windows.Input;

namespace Squads.UI.Controls;

public partial class IconButton : ContentView
{
    public IconButton()
    {
        InitializeComponent();
    }


    [AutoBindable(OnChanged = nameof(TextPropertyChanged))]
    private readonly string _text;
    private void TextPropertyChanged(string newValue)
    {
        TextLabel.Text = newValue?.ToString();
    }


    [AutoBindable(OnChanged = nameof(CommandPropertyChanged))]
    private readonly ICommand _command;
    private void CommandPropertyChanged(ICommand newValue)
    {
        GestureRecognizers.Clear();
        CommandGesture.Command = newValue as ICommand;
    }


    [AutoBindable(OnChanged = nameof(IconPropertyChanged))]
    private readonly Icon _icon;
    private void IconPropertyChanged(Icon newValue)
    {
        IconLabel.Text = newValue.ToGlyph();
    }
}