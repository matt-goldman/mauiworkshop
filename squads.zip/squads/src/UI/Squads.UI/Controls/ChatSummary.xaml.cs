using Maui.BindableProperty.Generator.Core;
using Squads.Shared.DTOs;

namespace Squads.UI.Controls;

public partial class ChatSummary : ContentView
{
    public ChatSummary()
    {
        InitializeComponent();
    }

    [AutoBindable(OnChanged = nameof(OnChatChanged))]
    private ChatDto chat;

    private void OnChatChanged(ChatDto newValue)
    {
        if (newValue is null) return;
        
        ChatNameLabel.Text = newValue?.Name??ChatNameLabel.Text;

        if (newValue?.Messages.Count != 0)
        {
            ChatMessageLabel.Text = newValue.Messages.First().Message;
            ChatTimeLabel.Text = newValue.Messages
                .First()
                .SentUtc
                .ToLocalTime()
                .ToString("h:mmtt")
                .ToLower();
        }

        UserProfileDto? firstUser;

        firstUser = newValue.Users.Any(u => !u.IsMe) ? newValue.Users.First(u => !u.IsMe) : newValue.Users.First();

        if (!string.IsNullOrEmpty(firstUser.ProfilePictureUrl))
        {
            Avatar.ImageSource = firstUser.ProfilePictureUrl;
        }
        else
        {
            Avatar.Text = firstUser.FirstName.Substring(0, 1) + firstUser.LastName.Substring(0, 1);
        }
    }
}