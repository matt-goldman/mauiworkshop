﻿using Microsoft.Maui.Controls.Shapes;
using System.Globalization;

namespace Squads.UI.Converters;

public class IsMeToStrokeShapeConverter : IValueConverter
{
    private RoundRectangle _myGeometry => new RoundRectangle
    {
        CornerRadius = new CornerRadius(10, 10, 10, 1)
    };

    private RoundRectangle _notMyGeometry => new RoundRectangle
    {
        CornerRadius = new CornerRadius(10, 10, 1, 10)
    };


    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        return (bool)value ? _myGeometry : _notMyGeometry;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
        throw new NotImplementedException();
    }
}
