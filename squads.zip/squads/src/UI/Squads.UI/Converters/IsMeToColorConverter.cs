﻿using System.Globalization;

namespace Squads.UI.Converters;

public class IsMeToColorConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        if (value is bool isMe)
        {
            var colors = GetColors();

            return isMe ? colors.isMeColor : colors.notMeColor;
        }

        throw new ArgumentException("Value is not a bool", nameof(value));
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
        throw new NotImplementedException();
    }

    private (Color isMeColor, Color notMeColor) GetColors()
    {
        Color isMeColor;
        Color notMeColor;

        var currentTheme = App.Current.RequestedTheme;

        var isMeColorName = currentTheme == AppTheme.Dark ? "OutgoingBubbleColorDark" : "OutgoingBubbleColorLight";
        var notMeColorName = currentTheme == AppTheme.Dark ? "IncomingBubbleColorDark" : "IncomingBubbleColorLight";

        if (App.Current.Resources.TryGetValue(isMeColorName, out var meValue))
        {
            isMeColor = (Color)meValue;
        }
        else
        {
            throw new NullReferenceException("Color not found");
        }

        if (App.Current.Resources.TryGetValue(notMeColorName, out var notMeValue))
        {
            notMeColor = (Color)notMeValue;
        }
        else
        {
            throw new NullReferenceException("Color not found");
        }

        return (isMeColor, notMeColor);
    }
}