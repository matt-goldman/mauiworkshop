﻿namespace Squads.UI.Helpers;

public static class UrlHelpers
{
    public static string? TunneliseUrl(this string profilePicUrl)
    {
        if (string.IsNullOrWhiteSpace(profilePicUrl))
        {
            return null;
        }
        var apiUri = new Uri(App.ApiUri);

        if (apiUri.Host == "localhost")
        {
            return profilePicUrl;
        }

        var uri = new Uri(profilePicUrl);

        if (uri.Host == "localhost" || uri.Host.Contains("ngrok") || uri.Host.Contains("devtunnels"))
        {
            var path = uri.PathAndQuery;
            var query = uri.Query;

            return $"{apiUri.Scheme}://{apiUri.Host}{path}{query}";
        }

        return profilePicUrl;
    }
}