﻿namespace Squads.UI.Helpers;

public enum Icon
{
    Camera,
    Send,
    Bell,
    Chat,
    Settings,
    User,
    Group,
    Gallery,
    Edit,
    Save,
    Image,
    AddUser,
    SignIn

}

public static class Glyphs
{
    public const string Camera = "\uf256";
    public const string Send = "\U000f0098";
    public const string Bell = "\ue016";
    public const string Chat = "\ue2fa";
    public const string Settings = "\uea9e";
    public const string User = "\uf5ca";
    public const string Group = "\ue8ff";
    public const string Gallery = "\uf498";
    public const string Edit = "\ue5c1";
    public const string Save = "\U000f05f2";
    public const string Image = "\uf492";
    public const string AddUser = "\ue934";
    public const string SignIn = "\ue0bf";

    public static string ToGlyph(this Icon icon)
    {
        return icon switch
        {
            Icon.Camera => Camera,
            Icon.Send => Send,
            Icon.Bell => Bell,
            Icon.Chat => Chat,
            Icon.Settings => Settings,
            Icon.User => User,
            Icon.Group => Group,
            Icon.Gallery => Gallery,
            Icon.Edit => Edit,
            Icon.Save => Save,
            Icon.Image => Image,
            Icon.AddUser => AddUser,
            Icon.SignIn => SignIn,
            _ => string.Empty,
        };
    }
}