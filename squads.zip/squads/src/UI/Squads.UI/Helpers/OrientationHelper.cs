namespace Squads.UI.Helpers;

public static class OrientationHelper
{
    public static bool IsInPortraitMode => GetIsInPortraitMode();

    private static bool GetIsInPortraitMode()
    {
        if (DeviceInfo.Current.Idiom == DeviceIdiom.Phone)
        {
            return true;
        }

        if (DeviceInfo.Current.Idiom == DeviceIdiom.Tablet)
        {
            return Application.Current!.Windows[0].Page!.Width < Application.Current!.Windows[0].Page!.Height;
        }

        return false;
    }
}