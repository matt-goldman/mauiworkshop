namespace Squads.UI.Helpers;

public class LoginModel
{
    public string email { get; set; } = string.Empty;
    public string password { get; set; } = string.Empty;
}

public class RegisterModel
{
    public string email { get; set; } = string.Empty;
    public string password { get; set; } = string.Empty;
}


public class LoginResponse
{
    public string tokenType { get; set; }
    public string accessToken { get; set; }
    public int expiresIn { get; set; }
    public string refreshToken { get; set; }
}

public class RefreshModel
{
    public string refreshToken { get; set; } = string.Empty;
}