using System.Net.Http.Headers;

namespace Squads.UI.Helpers;

public class AuthenticationHandler(IAuthenticationService authService) : DelegatingHandler
{
    public const string AUTHENTICATED_CLIENT = "AuthenticatedClient";

    protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        var accessToken = await authService.GetAccessToken();

        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

        return await base.SendAsync(request, cancellationToken);
    }
}