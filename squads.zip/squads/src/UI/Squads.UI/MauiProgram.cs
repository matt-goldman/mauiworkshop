﻿using CommunityToolkit.Maui;
using Microsoft.Extensions.Logging;

namespace Squads.UI;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder
            .UseMauiApp<App>()
            .ConfigureFonts(fonts =>
            {
                fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
                fonts.AddFont("FluentSystemIcons-Filled.ttf", "FluentIcons");
            })
            .UseAutodependencies()
            .UseMauiCommunityToolkit();

        // handlers
        builder.Services.AddTransient<AuthenticationHandler>();
        builder.Services.AddHttpClient(AuthenticationHandler.AUTHENTICATED_CLIENT, client => client.BaseAddress = new Uri(App.ApiUri))
            .AddHttpMessageHandler<AuthenticationHandler>();

#if DEBUG
        builder.Logging.AddDebug();
#endif

        return builder.Build();
    }
}