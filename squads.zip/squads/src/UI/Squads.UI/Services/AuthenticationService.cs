namespace Squads.UI.Services;

public class AuthenticationService : IAuthenticationService
{
    private DateTime? _tokenExpires;
    private string? _accessToken;

    public async Task<bool> Login(LoginModel loginModel)
    {
        using var client = new HttpClient();
        client.BaseAddress = new Uri(App.ApiUri);

        var response = await client.PostAsJsonAsync("login", loginModel);

        if (response.IsSuccessStatusCode)
        {
            var loginResponse = await response.Content.ReadFromJsonAsync<LoginResponse>();

            await SetLoggedInState(loginResponse!);

            return true;
        }
        else
        {
            return false;
        }
    }

    public async Task<bool> RefreshToken()
    {
        string? refreshToken;

        if (DeviceInfo.Current.Platform == DevicePlatform.iOS || DeviceInfo.Current.Platform == DevicePlatform.MacCatalyst)
        {
            refreshToken = Preferences.Get("RefreshToken", string.Empty);
        }
        else
        {
            refreshToken = await SecureStorage.GetAsync("RefreshToken");
        }

        if (!string.IsNullOrWhiteSpace(refreshToken))
        {
            using var client = new HttpClient();
            client.BaseAddress = new Uri(App.ApiUri);

            var refreshModel = new RefreshModel
            {
                refreshToken = refreshToken
            };

            var response = await client.PostAsJsonAsync("refresh", refreshModel);

            if (response.IsSuccessStatusCode)
            {
                var loginResponse = await response.Content.ReadFromJsonAsync<LoginResponse>();

                await SetLoggedInState(loginResponse!);

                return true;
            }
        }

        return false;
    }

    public async Task<bool> Register(RegisterModel registerModel)
    {
        using var client = new HttpClient();
        client.BaseAddress = new Uri(App.ApiUri);

        var response = await client.PostAsJsonAsync("register", registerModel);

        if (response.IsSuccessStatusCode)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public async Task<string> GetAccessToken()
    {
        if ((_tokenExpires.HasValue && DateTime.UtcNow > _tokenExpires.Value.AddMinutes(-5)) || string.IsNullOrWhiteSpace(_accessToken))
        {
            var success = await RefreshToken();

            if (!success)
            {
                return string.Empty;
            }
        }

        return _accessToken!;
    }

    private async Task SetLoggedInState(LoginResponse loginResponse)
    {
        _accessToken = loginResponse.accessToken;
        _tokenExpires = DateTime.UtcNow.AddSeconds(loginResponse.expiresIn);

        if (DeviceInfo.Current.Platform == DevicePlatform.iOS || DeviceInfo.Current.Platform == DevicePlatform.MacCatalyst)
        {
            Preferences.Set("RefreshToken", loginResponse.refreshToken);
        }
        else
        {
            await SecureStorage.SetAsync("RefreshToken", loginResponse.refreshToken);
        }
    }
}
