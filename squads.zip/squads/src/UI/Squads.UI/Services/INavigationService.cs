﻿namespace Squads.UI.Services;

public interface INavigationService
{
    Task PushModalAsync<TPage>() where TPage : Page;
    Task PushModalAsync<TPage>(params object[] args) where TPage : Page;
    Task PopModalAsync();
    Task GoToAsync(string path, Dictionary<string, object>? navigationParams = null);
    void GoToRoot();
}
