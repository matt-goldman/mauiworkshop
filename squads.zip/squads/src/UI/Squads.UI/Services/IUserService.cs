using Squads.Shared.DTOs;

namespace Squads.UI.Services;

public interface IUserService
{
    Task<bool> UpdateProfileAsync(UserProfileDto dto);
    
    Task<UserProfileDto> GetMyProfileAsync();

    Task<bool> UploadProfilePhotoAsync(Stream stream);

    Task<IEnumerable<UserProfileDto>> GetUsers();

    Task<IEnumerable<UserProfileDto>> SearchUsers(string searchTerm);
}