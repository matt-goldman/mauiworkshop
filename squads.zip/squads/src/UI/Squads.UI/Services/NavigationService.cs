﻿namespace Squads.UI.Services;

public class NavigationService : INavigationService
{
    public async Task GoToAsync(string path, Dictionary<string, object>? navigationParams = null)
    {
        await PopModalAsync();
        await Shell.Current.GoToAsync(path, navigationParams);
    }

    public async Task PopModalAsync()
    {
        await App.Current!.Windows[0].Page!.Navigation.PopModalAsync();
    }

    public Task PushModalAsync<TPage>() where TPage : Page
    {
        return App.Current!.Windows[0].Page!.Navigation.PushModalAsync<TPage>();
    }

    public Task PushModalAsync<TPage>(params object[] args) where TPage : Page
    {
        return App.Current!.Windows[0].Page!.Navigation.PushModalAsync<TPage>(args);
    }

    public void GoToRoot()
    {
       App.Current!.Windows[0].Page = new AppShell();
    }
}
