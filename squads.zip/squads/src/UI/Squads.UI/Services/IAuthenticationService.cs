namespace Squads.UI.Services;

public interface IAuthenticationService
{
    Task<bool> Login(LoginModel loginModel);
    Task<bool> Register(RegisterModel registerModel);
    Task<bool> RefreshToken();
    Task<string> GetAccessToken();
}