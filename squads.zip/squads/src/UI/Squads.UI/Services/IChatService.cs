﻿using Squads.Shared.DTOs;

namespace Squads.UI.Services;

public interface IChatService
{
    Task<ChatDto> GetChat(List<string> userIds);
    
    Task<List<ChatDto>> GetChats();

    Task<ChatDto> GetChat(string referralId);
}