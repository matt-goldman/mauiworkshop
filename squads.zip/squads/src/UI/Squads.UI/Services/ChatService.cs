﻿using Squads.Shared.DTOs;

namespace Squads.UI.Services;

public class ChatService : IChatService
{
    private readonly HttpClient _httpClient;

    public ChatService(IHttpClientFactory httpClientFactory)
    {
        _httpClient = httpClientFactory.CreateClient(AuthenticationHandler.AUTHENTICATED_CLIENT);
    }

    public async Task<ChatDto> GetChat(List<string> userIds)
    {
        var response = await _httpClient.PostAsJsonAsync($"api/chats/query?includeMessages=true", userIds);

        if (response.IsSuccessStatusCode)
        {
            var dto = await response.Content.ReadFromJsonAsync<ChatDto>();
            return dto;
        }
        else
        {
            return new ChatDto { Id = -1 };
        }
    }
    
    public async Task<List<ChatDto>> GetChats()
    {
        var response = await _httpClient.GetFromJsonAsync<List<ChatDto>>($"api/chats");

        return response;
    }

    public async Task<ChatDto> GetChat(string referralId)
    {
        var response = await _httpClient.GetFromJsonAsync<ChatDto>($"api/chats/{referralId}");

        return response;
    }
}