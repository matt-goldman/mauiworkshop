using Squads.Shared.DTOs;

namespace Squads.UI.Services;

public class UserService(IHttpClientFactory httpClientFactory) : IUserService
{
    private readonly HttpClient _httpClient = httpClientFactory.CreateClient(AuthenticationHandler.AUTHENTICATED_CLIENT);

    public async Task<UserProfileDto> GetMyProfileAsync()
    {
        var response = await _httpClient.GetAsync($"api/users");

        if (response.IsSuccessStatusCode)
        {
            var dto = await response.Content.ReadFromJsonAsync<UserProfileDto>();
            return dto;
        }
        else
        {
            return new UserProfileDto();
        }
    }

    public async Task<bool> UpdateProfileAsync(UserProfileDto dto)
    {
        var response = await _httpClient.PutAsJsonAsync($"api/users", dto);

        if (response.IsSuccessStatusCode)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public async Task<bool> UploadProfilePhotoAsync(Stream stream)
    {
        try
        {
            var response = await _httpClient.PostAsync($"api/users/profilepicture", new StreamContent(stream));

            if (response.IsSuccessStatusCode)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        catch (Exception)
        {
            return false;
        }
    }

    public async Task<IEnumerable<UserProfileDto>> GetUsers()
    {
        var response = await _httpClient.GetAsync($"api/users/all?page=1&pageSize=200");

        if (response.IsSuccessStatusCode)
        {
            var dto = await response.Content.ReadFromJsonAsync<IEnumerable<UserProfileDto>>();
            return dto;
        }
        else
        {
            return new List<UserProfileDto>();
        }
    }

    public async Task<IEnumerable<UserProfileDto>> SearchUsers(string searchTerm)
    {
        var response = await _httpClient.GetAsync($"api/users/search/{searchTerm}?page=1&pageSize=200");

        if (response.IsSuccessStatusCode)
        {
            var dto = await response.Content.ReadFromJsonAsync<IEnumerable<UserProfileDto>>();
            return dto;
        }
        else
        {
            return new List<UserProfileDto>();
        }
    }
}