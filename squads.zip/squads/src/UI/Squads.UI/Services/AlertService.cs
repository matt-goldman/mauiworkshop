﻿namespace Squads.UI.Services;

public class AlertService : IAlertService
{
    public Task DisplayAlert(string title, string message)
    {
        return App.Current.MainPage.DisplayAlert(title, message, "OK");
    }
}