﻿namespace Squads.Web;

public static class Constants
{
    public const string ApiUri = "https://api-service.salmonmoss-ad27fcd7.australiaeast.azurecontainerapps.io/";
}
