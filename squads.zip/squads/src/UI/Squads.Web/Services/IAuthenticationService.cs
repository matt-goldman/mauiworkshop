using Microsoft.AspNetCore.Components.Server.ProtectedBrowserStorage;
using Squads.Web.Helpers;
using Squads.Web.Models;

namespace Squads.Web.Services;

public interface IAuthenticationService
{
    public IDisposable Subscribe(Action<AuthenticationState> onChange);

    Task<string> Register(RegisterModel model);

    Task<bool> Login(LoginModel loginModel);
    
    Task Logout();

    Task<bool> RefreshToken();
    
    string? GetAccessToken();
}

public class AuthenticationService(IHttpClientFactory clientFactory, ProtectedLocalStorage protectedStore) : IAuthenticationService
{
    private readonly State<AuthenticationState> _state = new State<AuthenticationState>(new AuthenticationState(null, false));

    private readonly HttpClient client = clientFactory.CreateClient("AuthClient");

    public IDisposable Subscribe(Action<AuthenticationState> onChange) => _state.Subscribe(onChange);
    
    public async Task<string> Register(RegisterModel model)
    {
        var response = await client.PostAsJsonAsync("/register", model);

        if (response.IsSuccessStatusCode)
        {
            return await response.Content.ReadAsStringAsync();
        }

        return $"Failed: {await response.Content.ReadAsStringAsync()}";
    }

    public async Task<bool> Login(LoginModel loginModel)
    {
        var response = await client.PostAsJsonAsync("login", loginModel);

        if (response.IsSuccessStatusCode)
        {
            var loginResponse = await response.Content.ReadFromJsonAsync<LoginResponse>();

            await SetLoggedInState(loginResponse!);
            
            return true;
        }
        
        return false;
    }

    public async Task<bool> RefreshToken()
    {
        var refreshToken = await protectedStore.GetAsync<string>("RefreshToken");

        if (string.IsNullOrWhiteSpace(refreshToken.Value))
        {
            return false;
        }
        
        var refreshModel = new RefreshModel
        {
            refreshToken = refreshToken.Value
        };

        var response = await client.PostAsJsonAsync("refresh", refreshModel);

        if (response.IsSuccessStatusCode)
        {
            var loginResponse = await response.Content.ReadFromJsonAsync<LoginResponse>();

            await SetLoggedInState(loginResponse!);

            return true;
        }

        return false;
    }

    public Task Logout() => SetLoggedOutState();

    public string? GetAccessToken() => _state.CurrentValue.AccessToken;// ?? string.Empty;

    private async Task SetLoggedInState(LoginResponse loginResponse)
    {
        await protectedStore.SetAsync("RefreshToken", loginResponse.refreshToken);
        await protectedStore.SetAsync("TokenExpires", DateTime.UtcNow.AddSeconds(loginResponse.expiresIn));

        _state.SetValue(new AuthenticationState(loginResponse.accessToken, true));
    }

    private async Task SetLoggedOutState()
    {
        await protectedStore.DeleteAsync("RefreshToken");
        await protectedStore.DeleteAsync("TokenExpires");
        
        _state.SetValue(new AuthenticationState(null, false));
    }
}

public record AuthenticationState(string? AccessToken, bool IsLoggedIn);