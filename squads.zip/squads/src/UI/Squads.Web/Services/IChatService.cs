namespace Squads.Web.Services;

public interface IChatService
{
    
}