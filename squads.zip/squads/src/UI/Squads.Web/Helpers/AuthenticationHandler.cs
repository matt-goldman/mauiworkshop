﻿using System.Net.Http.Headers;
using Squads.Web.Services;

namespace Squads.Web.Helpers;

public class AuthenticationHandler(IAuthenticationService authService) : DelegatingHandler
{
    public const string AUTHENTICATED_CLIENT = "AuthenticatedClient";
    
    protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        var accessToken = authService.GetAccessToken();

        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

        return await base.SendAsync(request, cancellationToken);
    }
}
