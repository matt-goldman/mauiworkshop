﻿namespace Squads.Shared.Messages;

public class ChatMessage
{
    public int Id { get; set; }

    public int ChatId { get; set; }

    public string Message { get; set; } = string.Empty;

    public string SenderId { get; set; } = string.Empty;

    public string SenderName { get; set;} = string.Empty;

    public string SenderPicUrl { get; set; } = string.Empty;

    public DateTime SentUtc { get; set; }
}
