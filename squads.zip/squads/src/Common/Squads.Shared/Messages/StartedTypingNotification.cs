namespace Squads.Shared.Messages;

public class StartedTypingNotification
{
    public string UserId { get; set; }
    public int ChatId { get; set; }
}