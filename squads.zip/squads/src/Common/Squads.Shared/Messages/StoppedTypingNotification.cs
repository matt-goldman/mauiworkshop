namespace Squads.Shared.Messages;

public class StoppedTypingNotification
{
    public string UserId { get; set; }
    public int ChatId { get; set; }
}