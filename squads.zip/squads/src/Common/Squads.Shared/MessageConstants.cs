﻿namespace Squads.Shared;

public class MessageConstants
{
    public const string RECEIVE = "ReceiveMessage";
    public const string SEND = "SendMessage";
    public const string JOIN = "JoinChat";
    public const string ADD = "AddUserToChat";
    public const string LEAVE = "LeaveChat";
    public const string CREATE = "CreateChat";
    public const string START_TYPING = "StartTyping";
    public const string STOP_TYPING = "StopTyping";
}
