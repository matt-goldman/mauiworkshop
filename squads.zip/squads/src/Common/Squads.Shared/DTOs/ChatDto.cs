﻿using Squads.Shared.Messages;

namespace Squads.Shared.DTOs;

public class ChatDto
{
    public int Id { get; set; }

    public Guid ReferralId { get; set; } = Guid.NewGuid();

    public string Name { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public ICollection<ChatMessage> Messages { get; set; } = new List<ChatMessage>();

    public ICollection<UserProfileDto> Users { get; set; } = new List<UserProfileDto>();
}