﻿namespace Squads.Constants;

public static class ServiceConstants
{
    public const string STORAGE_SERCVICE = "storage-service";

    public const string PROFILE_BLOB = "profile-blob";

    public const string API_SERVICE = "api-service";

    public const string WEB_UI = "web-ui";

    public const string DATABASE_SERVER = "database-server";

    public const string SQUADS_DATABASE = "squads-database";
}
