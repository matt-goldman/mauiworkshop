<#
    .SYNOPSIS
        Generates the API client project

    .DESCRIPTION
        Generates the API client used by the web and mobile UI projects. The client is generated using Microsoft Kiota based on the OpenAPI specification published by your API service.

    .EXAMPLE
        Generate-ClientProject -ApiUrl https://my-azure-resource.my-region.azurecontainerapps.io

    .NOTES
        You need to provision your resources before running this script.

#>

# Params
param (
    [string(Mandatory = $true)]$ApiUrl
)

# check that the dotnet cli is installed

try {
    dotnet --version
} catch {
    Write-Error "The dotnet CLI is not installed. Please install it from https://dotnet.microsoft.com/download"
    exit 1
}

# check that the Kiota CLI is installed

$kiotaInstalled = $false

try {
    kiota --version
    $kiotaInstalled = $true
} catch {
    Write-Warning "The Kiota CLI is not installed. Installing it now..."
}

if (-not $kiotaInstalled) {
    try {
        dotnet tool install --global Microsoft.OpenApi.Kiota
        Write-Host "✅ Success! Kiota is now installed."
    }
    catch {
        Write-Error "Failed to install the Kiota CLI. Please install it manually using the following command: dotnet tool install --global Microsoft.OpenApi.Kiota, then run this script again."
        exit 1
    }
}


# Create the client project folder

$clientProjectFolder = "./src/Common/Squads.ApiClient"

if (-not (Test-Path $clientProjectFolder)) {
    New-Item -ItemType Directory -Path $clientProjectFolder
}

# generate the client project

kiota generate -l CSharp -c GeneratedClient -n Squads.ApiClient --openapi "$ApiUri/openapi/v1.json" -o ./src/Common/Squads.ApiClient/Generated -ebc
